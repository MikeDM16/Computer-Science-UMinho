--
-- Projecto CP 2015/16
--
-- O projecto consiste em desenvolver testes para o módulo Graph.hs
-- (para grafos orientados e não pesados).
-- Mais concretamente, o projecto consiste em 3 tarefas que são descritas abaixo.
-- O prazo para entrega é o dia 3 de Abril. Cada grupo deve enviar apenas
-- o módulo de testes (este módulo) por email para calculodeprogramas@gmail.com
-- O nome do ficheiro deve identificar os números dos 2 alunos do grupo (numero1_numero2.hs).
-- Certifiquem-se que o módulo de testes desenvolvido compila correctamente antes
-- de submeter. O módulo Graph.hs não deve ser alterado.
-- Os 2 alunos do grupo devem também indentificar-se nos comentários abaixo.
--
-- Aluno 1
-- Número: Ana Esmeralda Alves Fernandes 
-- Nome: A74321
-- Curso: Mestrado Integrado em Engenharia Informática
--
-- Aluno 2
-- Número: Miguel Dias Miranda
-- Nome: A74726
-- Curso: Mestrado Integrado em Engenharia Informática
--


module Main where

import Graph
import Test.HUnit hiding (path)
import Test.QuickCheck
import Data.Set as Set
import Control.Monad.State
import Data.Maybe

--
-- Teste unitário
--
e1 :: Edge Int
e1 = Edge {source=1, target=2} 

e2 :: Edge Int
e2 = Edge {source=2, target=1}  

e3 :: Edge Int 
e3 = Edge {source=5, target=5}

g0 :: Graph Int  
g0 = Graph {nodes = fromList[], 
            edges = fromList[]}

g1 :: Graph Int
g1 = Graph {nodes = fromList [1],
            edges = fromList [Edge 1 1]}

g2 :: Graph Int
g2 = Graph {nodes = fromList[1,2,3],
            edges = fromList[Edge 1 2, Edge 2 3, Edge 3 4]}

g3 :: Graph Int
g3 = Graph {nodes = fromList[1,2,3,4],
            edges = fromList[Edge 1 2, Edge 2 3, Edge 3 4]}

g4 :: Graph Int
g4 = Graph {nodes = fromList[1,2,3],
            edges = fromList[Edge 1 2, Edge 2 3, Edge 3 1]}

g4f :: Graph Int
g4f = Graph {nodes = fromList[1,2,3],
             edges = fromList[Edge 2 1, Edge 3 2]}

g5 :: Graph Int
g5 = Graph {nodes = fromList[1,2,3,4,5],
            edges = fromList[Edge 1 2, Edge 3 4]}
            
g6 :: Graph Int
g6 = Graph {nodes = fromList[2,3],
            edges = fromList[Edge 2 3]}

g7 :: Graph Int
g7 = Graph {nodes = fromList[2,3,4],
            edges = fromList[Edge 2 3, Edge 2 4]}

g3inv :: Graph Int
g3inv = Graph {nodes = fromList[1,2,3,4],
               edges = fromList[Edge 4 3, Edge 3 2, Edge 2 1]}
g8 :: Graph Int
g8 = Graph {nodes = fromList[1,2,3,4,5],
            edges = fromList[Edge 1 2, Edge 2 3, Edge 3 4]}

g9 :: Graph Int
g9 = Graph {nodes = fromList[1,2,3,4,5],
            edges = fromList[Edge 1 2, Edge 2 3, Edge 3 4, Edge 1 5, Edge 5 4]}

g10 :: Graph Int
g10 = Graph {nodes = fromList[1,2,3,4,5],
             edges = fromList[Edge 1 3, Edge 2 3, Edge 3 4, Edge 2 5]}

---------------------------------------------------------------------------------
-- Tarefa 1
--
-- Defina testes unitários para todas as funções do módulo Graph,
-- tentando obter o máximo de cobertura de expressões, condições, etc.
---------------------------------------------------------------------------------

test_swap :: Test
test_swap = TestList [swap e1 ~?= e2,
                      swap e3 ~?= e3]

test_empty :: Test
test_empty = TestList[ Graph.empty ~?= g0]

test_isEmpty :: Test
test_isEmpty = TestList[ isEmpty g0 ~?= True,
                         isEmpty g1 ~?= False]

test_isValid :: Test
test_isValid = TestList[ isValid g2 ~?= False,
                         isValid g0 ~?= True,
                         isValid g3 ~?= True]

test_DAG :: Test
test_DAG = TestList [ isDAG g0 ~?= True,
                      isDAG g4 ~?= False,
                      isDAG g3 ~?= True]

test_isForest :: Test
test_isForest = TestList [ isForest g0 ~?= True,
                           isForest g3 ~?= True,
                           isForest g4 ~?= False,
                           isForest g5 ~?= True]

test_SubgraphOf :: Test
test_SubgraphOf = TestList [ isSubgraphOf g6 g4 ~?= True,
                             isSubgraphOf g0 g0 ~?= True,
                             isSubgraphOf g4 g3 ~?= False,
                             isSubgraphOf g6 g7 ~?= True]

test_adj :: Test
test_adj = TestList[ adj g1 1 ~?= fromList [Edge 1 1],
                     adj g4 3 ~?= fromList[Edge 3 1],
                     adj g7 2 ~?= fromList[Edge 2 3, Edge 2 4]]

test_transpose :: Test
test_transpose = TestList[ transpose g0 ~?= g0,
                           transpose g1 ~?= g1,
                           transpose g3 ~?= g3inv]

test_union :: Test
test_union = TestList[ Graph.union g0 g4 ~?= g4,
                       Graph.union g5 g6 ~?= g8]

test_bft :: Test
test_bft = TestList[ bft g1 (fromList[]) ~?= g0,
                     bft g4 (fromList[1]) ~?=  g4f ]

test_reachable :: Test
test_reachable = TestList[ reachable g3  1 ~?= fromList[1, 2, 3, 4],
                          reachable g7 2 ~?= fromList[2, 3, 4],
                          reachable g0 3 ~?= fromList[3]]

test_isPathOf :: Test
test_isPathOf = TestList[ isPathOf [Edge 2 3] g3 ~?= True,
                          isPathOf [] g1 ~?= True,
                          isPathOf [Edge 1 2, Edge 2 3] g3 ~?= True,
                          isPathOf [Edge 4 5] g5 ~?= False]

test_path :: Test
test_path = TestList [ path g5 2 4 ~?= Nothing,
                       path g1 1 1 ~?= Just [],
                       path g9 1 4 ~?= Just [Edge 1 5, Edge 5 4] ] 

test_topo :: Test
test_topo = TestList[ topo g5 ~?= [fromList[1,3,5], fromList[2,4]],
                      topo g10 ~?= [fromList[1,2], fromList[3,5], fromList[4]],
                      topo g0 ~?= [] ]



{-
main = do
               runTestTT $ TestList ([test_swap]++ [test_empty] ++ [test_isEmpty] ++ 
                                    [test_isValid] ++ [test_DAG] ++ [test_isForest] ++
                                    [test_SubgraphOf] ++ [test_adj] ++ [test_transpose] ++
                                    [test_union] ++ [test_bft] ++ [test_reachable] ++
                                    [test_isPathOf] ++ [test_path] ++ [test_topo])
-}       

--
-- Teste aleatório 
--

--
-- Tarefa 2
--
-- A instância de Arbitrary para grafos definida abaixo gera grafos
-- com muito poucas arestas, como se pode constatar testando a
-- propriedade prop_valid.
-- Defina uma instância de Arbitrary menos enviesada.
-- Este problema ainda é mais grave nos geradores dag e forest que
-- têm como objectivo gerar, respectivamente, grafos que satisfazem
-- os predicados isDag e isForest. Estes geradores serão necessários
-- para testar propriedades sobre estas classes de grafos.
-- Melhore a implementação destes geradores por forma a serem menos enviesados.
--

--- Instância de Arbitrary para arestas
instance Arbitrary v => Arbitrary (Edge v) where
    arbitrary = do s <- arbitrary
                   t <- arbitrary
                   return $ Edge {source = s, target = t}

instance (Ord v, Arbitrary v) => Arbitrary (Graph v) where
    arbitrary = aux `suchThat` isValid
        where aux = do ns <- arbitrary
                       es <- arbitrary
                       return $ Graph {nodes = fromList ns, edges = fromList es}

{-instance Arbitrary Int => Arbitrary Int where
    arbitrary = do x <- arbitrary
                   return x

criaGrafo :: Gen (Graph Int)
criaGrafo = aux `suchThat` isValid
        where aux = do nRandom <- numeroRandom
                       nVertices <- numeroVertices nRandom
                       lEdges <- listaEdges nVertices
                       es <- arbitrary
                       return $ Graph {nodes = fromList lEdges, edges = fromList es}

-- Gerar um numero aleatório, positivo e diferente de zero 
numeroRandom :: Gen Int
numeroRandom = do x <- 
                  if(x/=0) then abs x else numeroRandom

-- Gerar um numero entre 0 e o número recebido como argumento.
numeroVertices :: Int -> Gen Int
numeroVertices r = choose(0, r)

listaEdges :: Int -> Gen [Int]
listaEdges n = if (n==0) then return [] 
               else do h <- arbitrary
                       t <- listaEdges (n-1)
                       return $ removeRepetidos (h:t)

removeRepetidos :: [Int] -> [Int]
removeRepetidos [] = []
removeRepetidos (h:t) = if (h `elem` t) then removeRepetidos t
                        else [h]++removeRepetidos t
{-
listaEdges ::  Int ->  Gen [v]
listaEdges 0 = return []
listaEdges n = listaEdgesAux sized []
        where listaEdgesAux s l = if (s==0) then return l  
                                  else do x <- arbitrary
                                          if( ( x `elem` l ) == False) then listaEdgesAux (s-1) ([x]++l)
                                          else listaEdgesAux s l -}

-- Gerador de DAGs
dag :: (Ord v, Arbitrary v) => Gen (DAG v)
dag = arbitrary `suchThat` isDAG

-- Gerador de florestas
forest :: (Ord v, Arbitrary v) => Gen (Forest v)
forest = arbitrary `suchThat` isForest


---------------------------------------------------------------------------
-- Tarefa 3
--
-- Defina propriedades QuickCheck para testar todas as funções
-- do módulo Graph.
--
---------------------------------------------------------------------------

prop_swap :: Edge Int -> Property
prop_swap v = property ((swap $ swap v) == v)

prop_empty :: Property
prop_empty = property (isEmpty(Graph.empty)==True)

prop_isEmpty :: Graph Int -> Property
prop_isEmpty g = property (isEmpty(Graph.empty) == True)

prop_isEmpty1 :: Graph Int -> Bool
prop_isEmpty1 g = if (nodes g == fromList[]) then (isEmpty g == True)
                  else (isEmpty g == False)

prop_isValid :: Graph Int -> Property
prop_isValid g = if (edges g /= fromList[]) then forAll (elements $ elems $ edges g) $ \e -> ( (aux 1 e) `elem` (nodes g) && (aux 2 e) `elem` (nodes g) )
                 else (nodes g == fromList[] && edges g == fromList[]) ==> (isValid g == True)

prop_valid :: Graph Int -> Property
prop_valid g = collect (length (edges g)) $ isValid g

aux :: Int ->  Edge Int -> Int
aux i (Edge x y) = if (i==1) then x else y  

prop_isDAG :: Graph Int -> Bool
prop_isDAG g = isForest g == isDAG g

prop_dag :: Property
prop_dag = forAll (dag :: Gen (DAG Int)) $ \g -> collect (length (edges g)) $ isDAG g

prop_isForest :: Graph Int -> Bool
prop_isForest g = isForest g == isDAG g

prop_forest :: Property
prop_forest = forAll (forest :: Gen (Forest Int)) $ \g -> collect (length (edges g)) $ isForest g

prop_subgraphOf :: Graph Int -> Graph Int -> Bool
prop_subgraphOf g g' = if (isSubgraphOf g g' == True) then ( ((Graph.union g g') == g')==True ) else ((Graph.union g g') == g')==False 

prop_subgraphOf1 :: Graph Int -> Property
prop_subgraphOf1 g = property (isSubgraphOf Graph.empty g == True)

prop_transpose :: Graph Int -> Property
prop_transpose g = property ((transpose $ transpose g) == g)

prop_adj :: Graph Int -> Property
prop_adj g = forAll (elements $ elems $ nodes g) $ \v -> adj g v `isSubsetOf` edges g

prop_union  :: Graph Int -> Graph Int -> Property
prop_union g g' = property (Graph.union g g' == Graph.union g' g)

prop_union1 :: Graph Int -> Property
prop_union1 g = property ( Graph.union g Graph.empty == g)

prop_bft :: Graph Int -> Set Int -> Property
prop_bft g vs = property ( (edges (transpose(bft g vs)) `isSubsetOf` (edges g) ))

prop_reachable :: Graph Int -> Int -> Property
prop_reachable g i = (forAll $ elements $ elems $ reachable g i) $ \x -> (path g i x /= Nothing)

prop_reachable1 :: Graph Int -> Graph Int -> Int -> Property
prop_reachable1 g g' i = property (reachable g i == reachable (Graph.union g g' ) i)

prop_isPathOf :: Graph Int -> Property
prop_isPathOf g = property (isPathOf [] g == True )

{-
prop_isPathOf1 :: Main.Path Int -> Graph Int -> Property
prop_isPathOf1 p g = (isPathOf p g == True && nodes g /=fromList[] && edges g /=fromList[]) 
                     ==> (path g (aux 1 (head p)) (aux 2 (last p)) /= Nothing)
-}
prop_path :: Graph Int -> Int -> Int -> Property
prop_path g i f = ((path g i f) /= Nothing) ==> (isPathOf (fromJust $ path g i f) g == True)

prop_path1 :: Graph Int -> Int -> Int -> Property
prop_path1 g i f = property ( (path g i f ) == (path (transpose g) i f) ) 

prop_path2 :: Graph Int -> Graph Int -> Int -> Int -> Property
prop_path2 g g' i f = property ( (path g i f ) == path (Graph.union g g') i f )

prop_topo :: DAG Int -> Bool
prop_topo g | (isDAG g) = ( sum $ Prelude.map length (topo g)) == length (nodes g)
            | otherwise = True

main = do quickCheck prop_swap
          {-quickCheck prop_isEmpty
          quickCheck prop_empty
          quickCheck prop_adj
          quickCheck prop_union
          quickCheck prop_union1
          quickCheck prop_transpose
          quickCheck prop_isDAG
          quickCheck prop_dag 
          quickCheck prop_path
          quickCheck prop_path1
          quickCheck prop_path2
          quickCheck prop_isForest
          quickCheck prop_forest 
          quickCheck prop_isEmpty1
          quickCheck prop_isValid
          quickCheck prop_valid
          quickCheck prop_subgraphOf
          quickCheck prop_subgraphOf1
          quickCheck prop_reachable 
          quickCheck prop_reachable1 
          quickCheck prop_isPathOf
          quickCheck prop_bft-}
          quickCheck prop_topo