#pragma once
#include "tinystr.h"
#include "tinyxml.h"

class Rotacao {

private:
	double angle;
	int axisX, axisY, axisZ;
public:
	Rotacao();
	Rotacao(double angle, int axisX, int axisY, int axisZ);
	
	static Rotacao Rotacao::parseRotacao(TiXmlElement* t);
	double getAngle();
	int getAxisX();
	int getAxisY();
	int getAxisZ();
};