#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <cmath>
#include <GL/glew.h>
#include <GL/glut.h>
#endif

#include "sistemaSolar.h"
#define _CRT_SECURE_NO_WARNINGS 
#define _USE_MATH_DEFINES
#include <math.h>

using namespace std;

Parsing* parsingXML;
Grupo* grupos;
std::vector<Grupo> vecGrupos;
GLuint* VBO_Modelos;
GLuint* VBO_CatmullRon;
int nrCatmullRoms;
int nrModelos, ind_atual = 0, ind_atualAux = 0;

// angle of rotation for the camera direction
float angleX = 0.0f;
float angleY = 0.0f;
float angleZ = 0.0f;
float beta = 0.0f;

/*Variaveis para a fun��o de FPS*/
int frame = 0, time, timebase = 0, fps;

// Straight line distance between the camera and look at point
float rCam = 100.0f;
float xxx = -50.0f;
float zzz = 0.0f;
float yyy = 0.0f;

//Variaveis para gerir a rota��o dos planetas na orbira
float spinOrbit = 0.1f; int rodar = 1, pausa = 1;

int comodesenha = 2;
float alpha = 0.0f;


void changeSize(int w, int h) {

	// Prevent a divide by zero, when window is too short
	// (you cant make a window with zero width).
	if (h == 0)
		h = 1;

	// compute window's aspect ratio 
	float ratio = w * 1.0 / h;

	// Set the projection matrix as current
	glMatrixMode(GL_PROJECTION);
	// Load Identity Matrix
	glLoadIdentity();

	// Set the viewport to be the entire window
	glViewport(0, 0, w, h);

	// Set perspective
	gluPerspective(45.0f, ratio, 1.0f, 1000.0f);

	// return to the model view matrix mode
	glMatrixMode(GL_MODELVIEW);
}
void preencheVBOsModelos(Grupo* grupos) {
	int iter = 0;
	vector<Modelo> modelos = grupos->getVecModels();
	for (auto modelo : modelos) {

		vector<Vertice> vertsModelo = modelo.getVertices();
		/*Cada v�rtice tem 3 coordenadas */
		int size = 3 * vertsModelo.size();
		double* vecCoordenadas = new double[size];

		for (auto vertice : vertsModelo) {
			vecCoordenadas[iter++] = vertice.getX();
			vecCoordenadas[iter++] = vertice.getY();
			vecCoordenadas[iter++] = vertice.getZ();
		}

		/*Tornar ativo o buffer que vai ter as coordenadas dos vertices do modelo atual*/
		glBindBuffer(GL_ARRAY_BUFFER, VBO_Modelos[ind_atual]);
		/*Preencher o buffer com os v�rtices do modelo atual*/
		glBufferData(GL_ARRAY_BUFFER, size * sizeof(double), vecCoordenadas, GL_STATIC_DRAW);

		/*Incrementar o indice do buffer, para que o proximo modelo lido fique guardado
		na proxima posi��o do array de VBOs. */
		ind_atual++;

		/*Se um grupo tiver descendencia, esta deve ser adicionada primeiro �
		estrutura dos VBOs*/
		Grupo* aux = grupos->getFilho();
		if (aux) { preencheVBOsModelos(aux); }

		/*Depois de analisar se tem filhos, s� depois podem ser adicionados os irmaos
		� estrutura de dados com os VBOs*/
		aux = grupos->getIrmao();
		if (aux) { preencheVBOsModelos(aux); }
	}
}

float size = 1;

void desenhaGrupo(Grupo *g) {
	Translacao trans = g->getT(); Rotacao rot = g->getR();	Escala esc = g->getE();
	vector<Modelo> vecModelos = g->getVecModels(); Cor c = g->getCor(); Orbita orb = g->getOrbita();
	double angle; float x, y, z, f;
	f = orb.getF();
	vector<Vertice> vertices;
	
	glPushMatrix();

	if (f) glRotatef(f*spinOrbit, orb.getX(), orb.getY(), orb.getZ());

	//realizar transla��o
	x = trans.getX(); y = trans.getY(); z = trans.getZ();
	glTranslatef(x, y, z);

	//realizar escala
	x = esc.getX(); y = esc.getY(); z = esc.getZ();
	glScalef(x, y, z);

	//realizar rota��e
	angle = rot.getAngle(); x = rot.getAxisX(); y = rot.getAxisY(); z = rot.getAxisZ();
	glRotatef(angle, x, y, z);

	//desenhar modelos
	for (Modelo modelo : vecModelos) {
		glBindBuffer(GL_ARRAY_BUFFER, VBO_Modelos[ind_atual]);
		glVertexPointer(3, GL_DOUBLE, 0, 0);

		glColor3f(c.getR(), c.getG(), c.getB());

		/*sem lista de indices */
		glDrawArrays(GL_TRIANGLES, 0, modelo.getVertices().size());

		ind_atual++;
		if (ind_atual == nrModelos) { ind_atual = 0; }

	}//Fim desenhar Modelos
	 
	Grupo* aux = g->getFilho();
	if (aux) {
		desenhaGrupo(g->getFilho());
	}

	glPopMatrix();
	
	aux = g->getIrmao();
	if (aux) {
		desenhaGrupo(aux);
	}
}

void countFPS() {
	frame++;
	time = glutGet(GLUT_ELAPSED_TIME);
	if (time - timebase > 1000) {
		double fps = (frame*1000.0 / (time - timebase));
		auto str = std::to_string(fps);
		glutSetWindowTitle(str.c_str());
		timebase = time;
		frame = 0;
	}
}
void renderScene(void) {
	// clear buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	float cX = rCam * -sinf((alpha)*(M_PI / 180)) * cosf((beta)*(M_PI / 180));
	float cY = rCam * -sinf((beta)*(M_PI / 180));
	float cZ = -rCam * cosf((alpha)*(M_PI / 180)) * cosf((beta)*(M_PI / 180));

	// Set the camera position and lookat point
	gluLookAt(cX, cY, cZ,   // Camera position
		0.0, 0.0, 0.0,    // Look at point
		0.0, 1.0, 0.0);   // Up vector;
	// Put the geometric transformations here
	if (comodesenha == 1) glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	if (comodesenha == 2) glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	if (comodesenha == 3) glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
	glRotatef(angleY, 0, 1, 0);
	glRotatef(angleX, 1, 0, 0);
	glRotatef(angleZ, 0, 0, 1);
	glTranslatef(xxx, yyy, zzz);
	
	// put drawing instructions here
	Grupo* raizGrupos = parsingXML->getGrupoRaiz();
	desenhaGrupo( raizGrupos );
	countFPS();
	if( pausa == 0 ) { spinOrbit += 0.05; }
	glEnd();
	// End of frame
	glutSwapBuffers();
}

// write function to process keyboard events
void arrows(int key_code, int xx, int yy) {
	//frac��o em que v�o aumentar os angulos
	float fraction = 0.9f;
	switch (key_code) {
	case GLUT_KEY_LEFT:
		alpha += fraction;
		break;
	case GLUT_KEY_RIGHT:
		alpha -= fraction;
		break;
	case GLUT_KEY_DOWN:
		if (abs((beta + fraction)*(M_PI / 180))<1.5)
			beta += fraction;
		break;
	case GLUT_KEY_UP:
		if (abs((beta - fraction)*(M_PI / 180))<1.5)
			beta -= fraction;
		break;
	}
	glutPostRedisplay();
};
/*Fun��o que atribui a fun��o de zoom �s teclas + e -, aumentando e diminuindo 
o zoom da camara, sem exceder a distancia de zoom maxima*/
void normalkeyboard(unsigned char tecla, int x, int y) {
	switch (tecla) {
	case '+': if (rCam > 1.0f) rCam -= 1.0f; break;
	case '-':  rCam += 1.0f; break;
	case 'w':  zzz -= 1.0f; break;
	case 'a':  xxx -= 1.0f; break;
	case 's':  zzz += 1.0f; break;
	case 'd':  xxx += 1.0f; break;
	case 't':  yyy -= 1.0f; break;
	case 'g':  yyy += 1.0f; break;
	case '1':  comodesenha = 1; break;
	case '2':  comodesenha = 2; break;
	case '3':  comodesenha = 3; break;
	case 'y':  angleX += 0.5f; break;
	case 'h':  angleX -= 0.5f; break;
	case 'u':  angleY += 0.5f; break;
	case 'j':  angleY -= 0.5f; break;
	case 'i':  angleZ += 0.5f; break;
	case 'k':  angleZ -= 0.5f; break;
	case 'r':  if (rodar == 0) { rodar = 1; pausa = 0; }
			   else { rodar = 0; pausa = 1;  spinOrbit = 0.0f; }
			   break;
	case 'p':  if (pausa == 0) { rodar = 0; pausa = 1; }
			   else { rodar = 1; pausa = 0; }
			   break;
	case 'o':  rCam = 60.0f;
			   angleX = 0; angleY = 0; angleZ = 0;
			   alpha = 0; beta = 0;
			   xxx = -30; yyy = 0; zzz = 0;
			   pausa = 1; rodar = 0; spinOrbit = 0.0f;
			   break;
	}

	glutPostRedisplay();
}



int main(int argc, char **argv) {

	if (argc == 1) {
		
		parsingXML = new Parsing("input.xml");
	}
	parsingXML = new Parsing(argv[1]);
	grupos = parsingXML->getGrupoRaiz();
	// put GLUT init here
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(1000, 800);
	glutCreateWindow("Trabalho Computa��o Gr�fica - Fase 2");

	// put callback registration here
	glutDisplayFunc(renderScene);
	glutReshapeFunc(changeSize);
	glutIdleFunc(renderScene);
	
	// put here the registration of the keyboard callbacks
	glutSpecialFunc(arrows);
	glutKeyboardFunc(normalkeyboard);
#ifndef __APPLE___
	glewInit();
#endif
	// OpenGL settings 
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	//Cor cinzenta;
	glClearColor(0.098, 0.098, 0.439, 1.0f);
	/*Determinar quantos modelos forma lidos do input e
	existem para renderizar. Existe um VBO para cada modelo	*/
	
	nrModelos = grupos->getNrModelos();
	cout << "fodue" << endl;
	VBO_Modelos = new GLuint[nrModelos];
	/*Gerar um buffer de vertices*/
	glGenBuffers(nrModelos, VBO_Modelos);
	
	preencheVBOsModelos(grupos);
	ind_atual = 0;
	ind_atualAux = 0;

	glEnableClientState(GL_VERTEX_ARRAY);
	// enter GLUT's main loop
 	glutMainLoop();

	return 1;
}

