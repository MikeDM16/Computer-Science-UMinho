#include "Translacao.h"

Translacao::Translacao(){
	this->x = this->y = this->z = 0;
}

Translacao::Translacao(float x, float y, float z){
	this->x = x;
	this->y = y;
	this->z = z;
}

Translacao Translacao::parseTranslacao(TiXmlElement* t) {
	float x, y, z;
	if (t != nullptr) {
		x = atof((char*)t->Attribute("X"));
		y = atof((char*)t->Attribute("Y"));
		z = atof((char*)t->Attribute("Z"));
	}
	else {
		x = y = z = 0;
	}

	return Translacao(x, y, z);
}

float Translacao::getX(){	return this->x; }
float Translacao::getY(){ return this->y; }
float Translacao::getZ(){ return this->z; }
