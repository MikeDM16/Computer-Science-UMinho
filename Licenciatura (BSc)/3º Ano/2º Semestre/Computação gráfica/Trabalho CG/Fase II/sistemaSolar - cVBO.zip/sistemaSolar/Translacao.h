#pragma once
#include "tinystr.h"
#include "tinyxml.h"

class Translacao {

private:
	float x, y, z;
public:
	Translacao();
	Translacao(float x, float y, float z);

	static Translacao Translacao::parseTranslacao(TiXmlElement* t);
	float getX();
	float getY();
	float getZ();
};