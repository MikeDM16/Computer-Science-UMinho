#include "Rotacao.h"

Rotacao::Rotacao() {
	this->angle = this->axisX = this->axisY = this->axisZ = 0;
}

Rotacao::Rotacao(double angle, int axisX, int axisY, int axisZ) {
	this->angle = angle;
	this->axisX = axisX;
	this->axisY = axisY;
	this->axisZ = axisZ;
}

Rotacao Rotacao::parseRotacao(TiXmlElement* r) {
	double angle;
	int x, y, z;
	if (r != nullptr) {
		angle = atof((char*)r->Attribute("angle"));
		x = atoi((char*)r->Attribute("axisX"));
		y = atoi((char*)r->Attribute("axisY"));
		z = atoi((char*)r->Attribute("axisZ"));
	}
	else {
		angle = x = y = z = 0;
	}

	return Rotacao(angle, x, y, z);
}

double Rotacao::getAngle() { return this->angle; }
int Rotacao::getAxisX() { return this->axisX; }
int Rotacao::getAxisY() { return this->axisY; }
int Rotacao::getAxisZ() { return this->axisZ; }
