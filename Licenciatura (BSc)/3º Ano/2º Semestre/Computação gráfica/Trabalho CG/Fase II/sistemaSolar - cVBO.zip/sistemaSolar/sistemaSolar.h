#pragma once
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>
#include "tinystr.h"
#include "tinyxml.h"
#include <direct.h>
// FASE I 

#include "Vertice.h"
#include "Modelo.h"
// Fase II
#include "Parsing.h"
#include "Translacao.h"
#include "Escala.h"
#include "Rotacao.h"
#include "Cor.h"
#include "Grupo.h"
#include "Orbita.h"

#define _USE_MATH_DEFINES
#include <math.h>

using namespace std;
