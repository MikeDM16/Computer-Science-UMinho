#include "Modelo.h"
using namespace std;

char* dir2patch = "C:\\Users/gamar/Onedrive/Trabalho CG/Fase IV/Gerador3d/Ficheiros/";
char* dir2patchJ = "C:\\Users/gamar/Desktop/Fase IV/sistemaSolar/Ficheiros/";
char* dir2patchE = "C:\\Users/aniie/Desktop/Fase IV/sistemaSolar/Ficheiros/";
char* dir2patchN = "C:\\Users/nadin/Desktop/CG/Fase IV/sistemaSolar/Ficheiros/";
char diretoriaFicheiro[256];

/*Construtor da classe*/
Modelo::Modelo(){}
/*Construtor da classe com parametros*/
Modelo::Modelo(std::vector<Triangulo> trianglinhos, vector<Vertice> normais){
	this->triangulos = trianglinhos;
	this->normais = normais;
}
Modelo::Modelo(std::vector<Triangulo> trianglinhos, vector<Vertice> normais, vector<float> textura) {
	this->triangulos = trianglinhos;
	this->normais = normais;
	this->coordTextura = textura;
}

std::vector<Triangulo> Modelo:: getTriangulos(){ return this->triangulos; }
vector<Vertice> Modelo::getNormais() { return this->normais; }
vector<float> Modelo::getCoordTextura() { return this->coordTextura;  }

void normalize(float *a) {

	float l = sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
	a[0] = a[0] / l;
	a[1] = a[1] / l;
	a[2] = a[2] / l;
}

void Modelo::escreveModelo(Modelo m, char* nameFile3d) {
	std::ofstream outfile3d(nameFile3d);

	vector<Triangulo> tris = m.getTriangulos();
	vector<Vertice> normais = m.getNormais();
	vector<float> coordText = m.getCoordTextura();

	outfile3d << tris.size() << endl; // Escrever Triangulos
	for (auto iter : tris) {
		Vertice v1 = iter.getV1();
		Vertice v2 = iter.getV2();
		Vertice v3 = iter.getV3();
		outfile3d << v1.getX() << " " << v1.getY() << " " << v1.getZ() << ", "
				  << v2.getX() << " " << v2.getY() << " " << v2.getZ() << ", "
				  << v3.getX() << " " << v3.getY() << " " << v3.getZ() << endl;
	}

	outfile3d << normais.size() << endl; // Escrever  Normais
	for (auto v : normais) {
		float n[3];
		n[0] = v.getX();
		n[1] = v.getY();
		n[2] = v.getZ();
		normalize(n);
		outfile3d << n[0] << " " << n[1] << " " << n[2] << endl;
	}

	// Escrever coordenadas textura
	if (coordText.size() > 0) { 
		outfile3d << coordText.size() << endl;
		for (int i = 0; i < coordText.size(); i+=2) {
			outfile3d << coordText.at(i) << " " << coordText.at(i + 1) << endl;
		}
	}else{ outfile3d << 0 << endl; }

	outfile3d.close();
	cout << "Escrita concluida do modelo" << endl;
}


vector<Patch> Modelo::lerFicheiro(char* file) {
	char dirFile[256];
	vector<Patch> patches; 
	//Conctena��o do nome do ficheiro com a diretoria que leva at� ao ficheiro
	strcpy_s(dirFile, dir2patch);
	strcat_s(dirFile, file);
	cout << "Ficheiro com os patches de bezier localizado na diretoria:\n " << dirFile << endl;
	ifstream inputfile(dirFile);
	if (!inputfile.is_open()) {
		cout << "Nao foi encontrado nenhum ficheiro na diretoria " << dirFile << endl;
	}
	else {
		int i, j, nrPatches, nrControlPoints;

		/*vector com todos os patchs lidos.	Cada patch tem sermpre 16 indices*/
		vector<array<int, 16>> VecIndPatch;

		vector<Vertice> VecVertices;

		char linha[128];
		//Ciclo de itera��o do ficheiro at� EOF 
		for (i = 0; inputfile.getline(linha, 128); i++) {
			//N�mero de patchs � dado na primeira linha
			if (i == 0) { nrPatches = atoi(linha); }

			if ((i > 0) && (i <= nrPatches)) {
				array<int, 16> indicesPatchAux;
				char* aux; aux = strtok(linha, ", ");
				for (j = 0; j < 16; j++) { 
					indicesPatchAux[j] = atoi(aux);
					aux = strtok(NULL, ", ");
				}
				VecIndPatch.push_back(indicesPatchAux);
			}

			//Depois da listagem dos indices de cada patch � dito o # de pontos de controlo
			if (i == nrPatches + 1) { nrControlPoints = atoi(linha); }

			if (i > (nrPatches + 1)) {
				vector<float> ponto(3);
				char* aux; aux = strtok(linha, ", ");
				for (j = 0; j < 3; j++) { 
					ponto[j] = stod(aux); 
					aux = strtok(NULL, ", ");
				}
				VecVertices.push_back(Vertice::Vertice(ponto[0], ponto[1], ponto[2]));
			}
		}
		cout << "nr de patchs lidos " << VecIndPatch.size() << ", nr de pontos lidos " << VecVertices.size() << endl;
		inputfile.close();

		//Iterar o vector com todos os indices para cada patch
		for (auto indicePatch : VecIndPatch) {
			Patch patchAux = Patch::Patch();
			i = 0;
			//iterar todos os elementos de um determinado patch
			for (auto elem : indicePatch) {
				/*Construir um patch com 16 pontos de control.
				  O Vertice de controlo da posi��o i do patch � igual ao Vertice,
				  no vector com todos os vertices, que est� na posi��o "elem"
				  */
				patchAux.setVertice( i, VecVertices.at(elem) );
				i++;
			}
			patches.push_back(patchAux);
		}
	}
	return patches;
}

void Modelo::bezier(char* file, int tesselation) {
	int trisTotal = 0;
	float passo, u, v;
	vector<Triangulo> tris;
	vector<Patch> patches = Modelo::lerFicheiro(file);
	vector<Vertice> normais;
	for (auto patch : patches) {
		Matriz Px = Matriz::patchToMatriz(patch, 1);
		Matriz Py = Matriz::patchToMatriz(patch, 2);
		Matriz Pz = Matriz::patchToMatriz(patch, 3);

		passo = 1.0 / tesselation;
		for (u = 0.0; u < 1; u += passo) {
			for (v = 0.0; v < 1; v += passo) {
				Vertice v1 = Vertice(Matriz::getPontoB(u, v, Px), Matriz::getPontoB(u, v, Py), Matriz::getPontoB(u, v, Pz));
				Vertice v2 = Vertice(Matriz::getPontoB(u + passo, v, Px), Matriz::getPontoB(u + passo, v, Py), Matriz::getPontoB(u + passo, v, Pz));
				Vertice v3 = Vertice(Matriz::getPontoB(u + passo, v + passo, Px), Matriz::getPontoB(u + passo, v + passo, Py), Matriz::getPontoB(u + passo, v + passo, Pz));
				Vertice v4 = Vertice(Matriz::getPontoB(u, v + passo, Px), Matriz::getPontoB(u, v + passo, Py), Matriz::getPontoB(u, v + passo, Pz));
				
				tris.insert(tris.end(), { Triangulo(v1,v2,v3), Triangulo(v1,v3,v4) });
				normais.insert(normais.end(), { v1,v2,v3,v1,v3,v4 }); // NORMAL = VERTICE -> Deve ser corrigido
				trisTotal += 2;
			}
		}
	}

	Modelo bezier = Modelo(tris, normais);
	cout << "trian total " << trisTotal << endl;
	escreveModelo(bezier, "bezier.3d");
	cout << "O modelo feito a partir de patch de bezier foi criado com sucesso no ficheiro bezier.3d" << endl;

}

/*------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------ Modelos da Fase I -------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------*/

void Modelo::cone(float raio, float altura, int fatias, int stacks, char* nameFile3d) {
	float angFatias = 2 * M_PI / fatias;
	float paramY = altura / stacks;

	std::vector<Triangulo> tris;
	vector<Vertice> normais;
	float iterY, yinf, ysup, angulo;
	yinf = - altura / 2;

	float rinf, rsup, r = 0;
	for (iterY = 0; iterY < stacks; iterY++) {
		// iterar o eixo dos YY para as stacks 
		ysup = yinf + paramY;
		for (angulo = 0; angulo < 2 * M_PI; angulo += angFatias) {
			// iteras as v�rias fatias
			rinf = raio - raio*iterY / stacks;
			rsup = raio - (raio*(iterY+1)) / stacks;
			Vertice v1 = Vertice::cilindricas(rinf, angulo, yinf);
			Vertice v2 = Vertice::cilindricas(rinf, angulo + angFatias, yinf);
			Vertice v3 = Vertice::cilindricas(rsup, angulo, ysup);
			Vertice v4 = Vertice::cilindricas(rsup, angulo + angFatias, ysup);

			tris.insert(tris.end(), { Triangulo(v2,v4,v3), Triangulo(v2,v3,v1) });
			normais.insert(normais.end(), { v2,v4,v3,v2,v3,v1 }); // NORMAL = VERTICE -> Deve ser corrigido

			if (yinf == -altura / 2) {
				//Condi��o para criar os triangulos da base do cone
				Vertice o = Vertice(0, -altura / 2, 0); // Vertice do centro do circulo da base do cone
				tris.insert(tris.end(), { Triangulo(v1,o,v2)});
				Vertice n = Vertice(0, -1, 0); // NORMAL = vetor down
				normais.insert(normais.end(), { n,n,n }); 
			}
		}
		yinf = ysup;
	}

	Modelo cone = Modelo(tris, normais);
	escreveModelo(cone, nameFile3d);
	cout << "O modelo do cone foi criado com sucesso no ficheiro "
		<< nameFile3d << "." << endl;
}

void Modelo::sphere(float raio, int fatias, int stacks, char* nameFile3d) {
	float angStacks = M_PI / stacks;
	float angSlices = 2 * M_PI / fatias;
	
	float passosY = 1.0f / stacks;
	float passosX = 1.0f / fatias;
	float deltaY, deltaX;
	
	std::vector<Triangulo> tris;
	vector<Vertice> normais;
	vector<float> coordenadastextura; float u1, vv1, u2,vv2,u3,vv3,u4,vv4; 

	float alpha, beta;
	for (deltaY = 0, beta = M_PI*0.5f; beta > -M_PI*0.5f; deltaY += passosY, beta -= angStacks) {
		for (alpha = 0, deltaX = 0; alpha < 2 * M_PI; deltaX += passosX, alpha += angSlices) {
			Vertice v1 = Vertice::esfericas(raio, alpha, beta);
			u1 = deltaX; vv1 = deltaY;
			
			Vertice v2 = Vertice::esfericas(raio, alpha + angSlices, beta);
			u2 = deltaX + passosX; vv2 = deltaY;

			Vertice v3 = Vertice::esfericas(raio, alpha + angSlices, beta - angStacks);
			u3 = deltaX + passosX; vv3 = deltaY + passosY;

			Vertice v4 = Vertice::esfericas(raio, alpha, beta - angStacks);
			u4 = deltaX; vv4 = deltaY + passosY;

			tris.insert(tris.end(), { Triangulo(v3,v2,v4), Triangulo(v4,v2,v1)});
			normais.insert(normais.end(), { v3,v2,v4,v4,v2,v1});
			coordenadastextura.insert(coordenadastextura.end(), { u3,1-vv3, u2,1-vv2, u4,1-vv4, u4,1-vv4, u2,1-vv2, u1,1-vv1 });
		}
	}

	Modelo esfera = Modelo(tris, normais, coordenadastextura);
	escreveModelo(esfera, nameFile3d);
	std::cout << "O modelo da esfera foi criado com sucesso no ficheiro "
		<< nameFile3d << "." << endl;
}

void Modelo::cilindro(float raio, float altura, int fatias, int stacks, char* nameFile3d) {
	float angFatias = 2 * M_PI / fatias; 
	float paramY = altura / stacks;
	float yinf, ysup, ang = 0, x1,x2,z1,z2;
	int iterY;
	std::vector<Triangulo> tris;
	vector<Vertice> normais;
	float y = (float) altura / 2;

	vector<float> coordText;
	float u1, vv1, u2, vv2, u3, vv3, u4, vv4;
	float passoX, passoY, deltaXinf, deltaXsup, deltaYinf, deltaYsup;
	passoY = (float) 0.625f / stacks;
	passoX = (float) 1 / fatias;

	yinf = (float) -altura / 2;
	deltaYinf = (float) 0.375f;
	for (iterY = 0; iterY < stacks; iterY++) {
		//iterar o eixo dos Y, conforme o numero de stacks
		ysup = yinf + paramY;
		deltaXinf = 0.0f;
		deltaYsup = deltaYinf + passoY;
		for (ang = 0; ang < 2 * M_PI; ang += angFatias) { 
			deltaXsup = deltaXinf + passoX;
			//rodar desde 0 a 2*pi cada nivel stack para compor os triangulos
			x1 = (float) raio*cos(ang);
			x2 = (float) raio*cos(ang + angFatias);
			z1 = (float) raio*sin(ang);
			z2 = (float) raio* sin(ang + angFatias);
			//Considerando cada stack como um anel, v1 e v2 v�o estar na circunferencia inferior
			Vertice v1 = Vertice(x1, yinf, z1);
			u1 = 1 - deltaXinf; vv1 = deltaYinf;
			Vertice v2 = Vertice(x2, yinf, z2);
			u2 = 1 - deltaXsup; vv2 = deltaYinf;
			//Considerando cada stack como um anel, v3 e v4 v�o estar na circunferencia superior
			Vertice v3 = Vertice(x1, ysup, z1);
			u3 = 1- deltaXinf; vv3 = deltaYsup;
			Vertice v4 = Vertice(x2, ysup, z2);
			u4 = 1 - deltaXsup; vv4 = deltaYsup;
			tris.insert(tris.end(), { Triangulo(v1,v4, v2), Triangulo(v1,v3,v4)});
			normais.insert(normais.end(), { v1,v4,v2,v1,v3,v4 }); // NORMAL = VERTICE -> Deve ser corrigido
			coordText.insert(coordText.end(), { u1,vv1, u4,vv4, u2,vv2, u1,vv1, u3,vv3, u4,vv4 });
			
			if (yinf == -y) {
				//Condi��o para gerar a face inferior do cilindro
				Vertice b1 = Vertice(0, yinf, 0); //Vertice do centro do circulo da base do cilindro
				u1 = (float) 0.8125; vv1 = (float) 0.1875;
				Vertice b2 = Vertice(x1, yinf, z1);
				u2 = (float) 0.8125 + ((float) 0.1875*sin(ang)); vv2 = (float) 0.1875 + ((float) 0.1875*cos(ang));
				Vertice b3 = Vertice(x2, yinf, z2);
				u3 = (float) 0.8125 + 0.1875*sin(ang + angFatias); vv3 = (float) 0.1875 + ((float) 0.1875*cos(ang + angFatias));
				tris.insert(tris.end(), { Triangulo(b3,b1,b2) }); // Face inferior
				Vertice n = Vertice(0,-1,0);
				normais.insert(normais.end(), { n,n,n }); // NORMAL = down
				coordText.insert(coordText.end(), { u3,vv3, u1,vv1, u2,vv2 });
			}
			if (iterY == stacks -1 ) {
				//Condi��o para gerar a face superior do cilindro
				Vertice v1 = Vertice(0, ysup, 0); //Vertice do centro do circulo do teto do cilindro
				u1 = (float) 0.4375; vv1 = (float) 0.1875;
				Vertice v2 = Vertice(x1, ysup, z1);
				u2 = (float) 0.4375 + ((float) 0.1875*sin(ang)); vv2 = (float) 0.1875 + ((float) 0.1875*cos(ang));
				Vertice v3 = Vertice(x2, ysup, z2);
				u3 = (float) 0.4375 + ((float)0.1875*sin(ang + angFatias)); vv3 = (float)0.1875 + ((float) 0.1875*cos(ang + angFatias));
				Vertice n = Vertice(0,1,0);
				tris.insert(tris.end(), { Triangulo(v2,v1,v3) });// Face superior
				normais.insert(normais.end(), { n,n,n }); // NORMAL = up
				coordText.insert(coordText.end(), { u2,vv2, u1,vv1, u3,vv3 });
			}
			cout << "xinf :" << deltaXinf << ", xsup: " << deltaXsup << ", yinf: " << deltaYinf << ", ysup: " << deltaYsup << endl;
			deltaXinf = deltaXsup;

		}
		yinf = ysup;
		deltaYinf = deltaYsup;
	}

	Modelo cilindro = Modelo(tris, normais, coordText);
	escreveModelo(cilindro, nameFile3d);
	cout << "O modelo do cilindro 1 foi criado com sucesso no ficheiro "
		<< nameFile3d << "." << endl;
}

void Modelo::box(float largura, float compri, float altura, float nDiv, char* nameFile3d) {
	float x = largura / 2, y = altura / 2, z = compri / 2;
	float paramY = (altura / nDiv);
	float paramX = largura / nDiv;
	float paramZ = compri / nDiv;

	std::vector<Triangulo> tris;
	vector<Vertice> normais;
	vector<float> coordTextura;

	int iterX, iterY, iterZ;
	float xinf, xsup, yinf, ysup, zinf, zsup;

	float passosX = (float) 0.25 / nDiv;
	float passosY = (float)(1.0f / 3.0f) / nDiv;
	float deltaXinf, deltaXsup, deltaYinf, deltaYsup;
	float u1, vv1, u2, vv2, u3, vv3, u4, vv4;

	/*ciclo no eixo do y para criar as stacks*/
	yinf = -y;
	deltaYinf = (float)(1.0f / 3.0f); // para as texturas laterais a coordTextura V vai de 1/3 at� 2/3, em passos (1/3)/nDiv
	for (iterY = 0; iterY != nDiv; iterY++) {
		ysup = yinf + paramY;
		deltaYsup = deltaYinf + passosY; // para as texturas irem subindo a coordenada U

										 /*ciclo no eixo do x para criar as faces frontal e traseira*/
		xinf = -x;
		deltaXinf = 0.25; // para as texturas
		for (iterX = 0; iterX != nDiv; iterX++) {
			xsup = xinf + paramX;
			deltaXsup = deltaXinf + passosX; //para as texturas

											 /*Vertices da face Z positiva*/
			Vertice v1 = Vertice(xinf, yinf, z);
			u1 = deltaXinf; vv1 = deltaYinf;
			//u1 = 0; vv1 = 0;
			Vertice v2 = Vertice(xsup, yinf, z);
			u2 = deltaXsup; vv2 = deltaYinf;
			//u2 = 1; vv2 = 0;
			Vertice v3 = Vertice(xinf, ysup, z);
			u3 = deltaXinf; vv3 = deltaYsup;
			//u3 = 0; vv3 = 1;
			Vertice v4 = Vertice(xsup, ysup, z);
			u4 = deltaXsup; vv4 = deltaYsup;
			//u4 = 1; vv4 = 1;
			Vertice nZF = Vertice(1, 0, 0);
			tris.insert(tris.end(), { Triangulo(v2,v3,v1), Triangulo(v2,v4,v3) });
			normais.insert(normais.end(), { nZF,nZF,nZF, nZF,nZF,nZF });
			coordTextura.insert(coordTextura.end(), { u2,vv2, u3,vv3, u1,vv1, u2,vv2, u4,vv4, u3,vv3 });

			/*Vertice da Z negativa*/
			v1 = Vertice(xsup, yinf, -z);
			u1 = (1.25 - deltaXsup); vv1 = deltaYinf;
			//u1 = 0; vv1 = 0;
			v2 = Vertice(xinf, yinf, -z);
			u2 = (1.25 - deltaXinf); vv2 = deltaYinf;
			//u2 = 1; vv2 = 0;
			v3 = Vertice(xsup, ysup, -z);
			u3 = (1.25 - deltaXsup); vv3 = deltaYsup;
			//u3 = 0; vv3 = 1;
			v4 = Vertice(xinf, ysup, -z);
			u4 = (1.25 - deltaXinf); vv4 = deltaYsup;
			//u4 = 1; vv4 = 1;

			Vertice nZT = Vertice(-1, 0, 0);
			tris.insert(tris.end(), { Triangulo(v2,v4,v3), Triangulo(v2,v3,v1) }); //face traseira 
			normais.insert(normais.end(), { nZT,nZT,nZT, nZT,nZT,nZT });
			coordTextura.insert(coordTextura.end(), { u2,vv2, u4,vv4, u3,vv3, u2,vv2, u3,vv3, u1,vv1 });

			xinf = xsup;
			deltaXinf = deltaXsup;
		}

		zinf = -z;
		deltaXinf = (float) 0.0; //para as texturas das outras duas faces latereis, basta dar um salto de 0.25
		for (iterZ = 0; iterZ != nDiv; iterZ++) {
			zsup = zinf + paramZ;
			deltaXsup = deltaXinf + passosX; //para as texturas

											 /*Vertices da face X positiva */
			Vertice v1 = Vertice(x, yinf, zsup);
			u1 = (0.75 - deltaXsup); vv1 = deltaYinf;
			//u1 = 0; vv1 = 0;
			Vertice v2 = Vertice(x, yinf, zinf);
			u2 = (0.75 - deltaXinf); vv2 = deltaYinf;
			//u2 = 1; vv2 = 0;
			Vertice v3 = Vertice(x, ysup, zsup);
			u3 = (0.75 - deltaXsup); vv3 = deltaYsup;
			//u3 = 0; vv3 = 1;
			Vertice v4 = Vertice(x, ysup, zinf);
			u4 = (0.75 - deltaXinf); vv4 = deltaYsup;
			//u4 = 1; vv4 = 1;

			Vertice nXF = Vertice(0, 0, 1);
			tris.insert(tris.end(), { Triangulo(v2,v4,v3), Triangulo(v3,v1,v2) });
			normais.insert(normais.end(), { nXF,nXF,nXF, nXF,nXF,nXF });
			coordTextura.insert(coordTextura.end(), { u2,vv2, u4,vv4, u3,vv3, u3,vv3, u1,vv1, u2,vv2 });

			/*Vertice da face X negativa*/
			v1 = Vertice(-x, yinf, zsup);
			u1 = deltaXsup; vv1 = deltaYinf;
			//u1 = 0; vv1 = 0;
			v2 = Vertice(-x, yinf, zinf);
			u2 = deltaXinf; vv2 = deltaYinf;
			//u2 = 1; vv2 = 0;
			v3 = Vertice(-x, ysup, zsup);
			u3 = deltaXsup; vv3 = deltaYsup;
			//u3 = 0; vv3 = 1;
			v4 = Vertice(-x, ysup, zinf);
			u4 = deltaXinf; vv4 = deltaYsup;
			//u4 = 1; vv4 = 1;

			Vertice nXT = Vertice(0, 0, -1);
			tris.insert(tris.end(), { Triangulo(v1,v3,v4), Triangulo(v1,v4,v2) });
			normais.insert(normais.end(), { nXT,nXT,nXT, nXT,nXT,nXT });
			coordTextura.insert(coordTextura.end(), { u1,vv1, u3,vv3, u4,vv4, u1,vv1, u4,vv4, u2,vv2 });

			zinf = zsup;
			deltaXinf = deltaXsup;
		}

		yinf = ysup; // subir um camada na stack 
		deltaYinf = deltaYsup;
	}


	/*Ciclo nos eixos X e Z para criar as faces superior e inferior do cubo*/
	xinf = -x;
	deltaXinf = (float) 0.75;
	for (iterX = 0; iterX != nDiv; iterX++) {
		xsup = xinf + paramX;
		zinf = -z;
		deltaXsup = deltaXinf + passosX;

		deltaYinf = (float)(0.0f);
		for (iterZ = 0; iterZ != nDiv; iterZ++) {
			zsup = zinf + paramZ;
			deltaYsup = deltaYinf - passosY;

			/*Vertices da base inferior*/
			Vertice b1 = Vertice(xinf, -y, zsup);
			u1 = deltaXinf; vv1 = deltaYsup;
			//u1 = 0; vv1 = 0;
			Vertice b2 = Vertice(xsup, -y, zsup);
			u2 = deltaXsup; vv2 = deltaYsup;
			//u2 = 1; vv2 = 0;
			Vertice b3 = Vertice(xsup, -y, zinf);
			u3 = deltaXsup; vv3 = deltaYinf;
			//u3 = 0; vv3 = 1;
			Vertice b4 = Vertice(xinf, -y, zinf);
			u4 = deltaXinf; vv4 = deltaYinf;
			//u4 = 1; vv4 = 1;
			Vertice nI = Vertice(0, -1, 0);
			tris.insert(tris.end(), { Triangulo(b1,b4,b3), Triangulo(b1,b3,b2) });
			normais.insert(normais.end(), { nI,nI,nI, nI,nI,nI });
			coordTextura.insert(coordTextura.end(), { u1,vv1, u4,vv4, u3,vv3, u1,vv1, u3,vv3, u2,vv2 });

			zinf = zsup;
			deltaYinf = deltaYsup;
		}

		xsup = xinf + paramX;
		zinf = -z;
		deltaYinf = 0.0f; // para a face de cima, a coordenada V come�a em (2/3) e sube at� 1, em passos de (1/3)/nDiv
		for (iterZ = 0; iterZ != nDiv; iterZ++) {
			xsup = xinf + paramX;
			zsup = zinf + paramZ;
			deltaYsup = deltaYinf + passosY;

			/*Vertice da base superior*/
			Vertice s1 = Vertice(xinf, y, zsup);
			//u1 = 0; vv1 = 0;
			u1 = (0.5 - deltaXinf); vv1 = (1 - deltaYsup);
			Vertice s2 = Vertice(xsup, y, zsup);
			//u2 = 1; vv2 = 0;
			u2 = (0.5 - deltaXsup); vv2 = (1 - deltaYsup);
			Vertice s3 = Vertice(xsup, y, zinf);
			u3 = (0.5 - deltaXsup); vv3 = (1 - deltaYinf);
			//u3 = 0; vv3 = 1;
			Vertice s4 = Vertice(xinf, y, zinf);
			u4 = (0.5 - deltaXinf); vv4 = (1 - deltaYinf);
			//u4 = 1; vv4 = 1;
			Vertice nS = Vertice(0, 1, 0);

			tris.insert(tris.end(), { Triangulo(s2,s3,s4), Triangulo(s2,s4,s1) });
			normais.insert(normais.end(), { nS,nS,nS, nS,nS,nS });
			coordTextura.insert(coordTextura.end(), { u2,vv2, u3,vv3, u4,vv4, u2,vv2, u4,vv4, u1,vv1 });

			zinf = zsup;
			deltaYinf = deltaYsup;
		}
		xinf = xsup;
		deltaXinf = deltaXsup;
	}



	Modelo caixa = Modelo(tris, normais, coordTextura);
	escreveModelo(caixa, nameFile3d);
	cout << "O modelo da caixa foi criado com sucesso no ficheiro "
		<< nameFile3d << "." << endl;
}




void Modelo::plane(float ladoSqr, char* nameFile3d){
	float x = ladoSqr / 2;
	vector<float> coordTextura; 
	float u1, vv1, u2, vv2, u3, vv3, u4, vv4;
	Vertice v1 = Vertice(x, 0, x);	
	u1 = 1; vv1 = 0;
	Vertice v2 = Vertice(x, 0,-x);
	u2 = 0; vv2 = 0;
	Vertice v3 = Vertice(-x,0,-x);	
	u3 = 0; vv3 = 1;
	Vertice v4 = Vertice(-x, 0,x);
	u4 = 1; vv4 = 1;

	Vertice n  = Vertice(0,1, 0); // vetor up 
	vector<Triangulo> tris = { Triangulo(v1, v2, v3), Triangulo(v1, v3, v4) };
	vector<Vertice> normais;
	normais.insert(normais.end(), { n,n,n, n,n,n }); // NORMAL = vetor up 
	coordTextura.insert(coordTextura.end(), { u1,vv1, u2,vv2, u3,vv3, u1,vv1, u3,vv3, u4,vv4 });

	Modelo plano = Modelo( tris, normais, coordTextura );
	escreveModelo(plano, nameFile3d);

	cout << "O modelo do plano foi criado com sucesso no ficheiro "
		<< nameFile3d << "." << endl;
}


