#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include "Vertice.h"

class Triangulo{

	private:
		Vertice v1;
		Vertice v2;
		Vertice v3;
	public:
		/*Contrutor padrão */	
		Triangulo();
		/*Construtor da classe. Recebe como parametros os 3 vertices que vão
		dar origem ao triangulo*/
		Triangulo(Vertice v1, Vertice v2, Vertice v3);

		/*getters dos três vertices que compôe um triangulo*/
		Vertice Triangulo::getV1();
		Vertice Triangulo::getV2();
		Vertice Triangulo::getV3();
};