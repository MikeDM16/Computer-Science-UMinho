#pragma once
#define _CRT_SECURE_NO_WARNINGS

class Vertice{

	private:
		float x,y,z;

	public:
		/*Construtor padr�o */
		Vertice::Vertice();
		/*Contrutor de um vertice, caracterizados pelas suas tres 
		coordenadas espaciais x, y e z */
		Vertice::Vertice(float x, float y, float z);

		/*Fun��o que dado as coordenadas de um vertice em coordenadas cilindricas
		as converte para um referencial cartesiano. Fun��o necess�ria para calcular os vertices de
		um cone*/
		static Vertice cilindricas(float raio, float alpha, float y);

		/*Fun��o que dado as coordenadas de um vertice em coordenadas esf�ricas
		as converte para um referencial cartesiano. Fun��o necess�ria para a cria�ao dos
		vertices de um esfera*/
		static Vertice Vertice::esfericas(float raio, float alpha, float beta);

		/*Metodos get das variaveis da classe  Vertice*/
		float Vertice::getX();
		float Vertice::getY();
		float Vertice::getZ();

};