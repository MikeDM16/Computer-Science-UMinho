#include "Patch.h"

Patch::Patch() {}

Vertice Patch::getVert(int p) {	return this->vertices[p]; }

void Patch::setVertice(int i, Vertice v) { this->vertices[i] = Vertice::Vertice(v.getX(), v.getY(), v.getZ());	}

array<Vertice, 16> Patch::getVertices() { return this->vertices; }