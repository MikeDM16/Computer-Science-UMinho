#include <iostream>
#include "Vertice.h"
using namespace std;

Vertice::Vertice(){}

Vertice::Vertice(float x, float y, float z){
	this->x = x; this->y = y; this->z = z;
}

Vertice Vertice::esfericas(float raio, float alpha, float beta) {
	float x = raio * sin(alpha) * cos(beta);
	float y = raio * sin(beta);
	float z = raio * cos(alpha) * cos(beta);

	return Vertice(x, y, z);
}

Vertice Vertice::cilindricas(float raio, float alpha, float y) {
	float x = raio * sin(alpha);
	float z = raio * cos(alpha);
	return Vertice(x, y, z);
}
float Vertice::getX() {	return this->x;	}
float Vertice::getY() {	return this->y;	}
float Vertice::getZ() {	return this->z;	}


