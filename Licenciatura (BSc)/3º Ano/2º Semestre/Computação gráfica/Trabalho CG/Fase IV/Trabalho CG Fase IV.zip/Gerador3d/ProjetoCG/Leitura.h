#pragma once
#include "Vertice.h"
#include <vector>
using namespace std;

typedef array<Vertice, 16> Patch;

class Leitura {

private:


public:
	static std::vector<Patch> lerFicheiro(char* file);
};