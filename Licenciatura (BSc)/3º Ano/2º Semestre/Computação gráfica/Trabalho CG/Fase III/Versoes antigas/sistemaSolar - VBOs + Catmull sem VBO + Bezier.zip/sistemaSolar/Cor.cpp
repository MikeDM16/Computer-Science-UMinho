#include "Cor.h"

Cor::Cor(){
	this->r = this->g = this->b = 0;
}

Cor::Cor(float r, float g, float b){
	this->r = r;
	this->g = g;
	this->b = b;
}

Cor Cor::parseCor(TiXmlElement* c) {
	float r, g, b;
	if (c!= nullptr) {
		r = atof((char*)c->Attribute("R"));
		g = atof((char*)c->Attribute("G"));
		b = atof((char*)c->Attribute("B"));
	}
	else {
		r = g = b = 0;
	}

	return Cor(r, g, b);
}

float Cor::getR(){ return this->r; }
float Cor::getG(){ return this->g; }
float Cor::getB(){ return this->b; }
