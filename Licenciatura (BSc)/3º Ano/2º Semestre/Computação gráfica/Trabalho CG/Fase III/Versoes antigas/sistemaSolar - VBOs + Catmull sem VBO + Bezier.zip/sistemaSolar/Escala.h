#pragma once
#include "tinystr.h"
#include "tinyxml.h"

class Escala {

private:
	float x, y, z;
public:
	Escala();
	Escala(float x, float y, float z);

	static Escala Escala::parseEscala(TiXmlElement* t);
	float getX();
	float getY();
	float getZ();
};