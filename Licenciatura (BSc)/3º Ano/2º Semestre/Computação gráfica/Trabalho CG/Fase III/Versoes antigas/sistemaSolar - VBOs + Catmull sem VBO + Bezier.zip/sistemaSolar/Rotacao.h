#pragma once
#include "tinystr.h"
#include "tinyxml.h"

class Rotacao {

private:
	double time;
	int axisX, axisY, axisZ;
public:
	Rotacao();
	Rotacao(double time, int axisX, int axisY, int axisZ);
	
	static Rotacao Rotacao::parseRotacao(TiXmlElement* t);
	double getTime();
	int getAxisX();
	int getAxisY();
	int getAxisZ();
};