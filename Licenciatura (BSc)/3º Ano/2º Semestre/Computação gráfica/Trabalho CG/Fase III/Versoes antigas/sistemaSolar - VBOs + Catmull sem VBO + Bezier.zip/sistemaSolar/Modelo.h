#include <vector>
#include "Vertice.h"
#pragma once

class Modelo{
	
	private:
		std::vector<Vertice> vertices;

	public:
		/*Contrutor padrão */
		Modelo();
		/*Construtor da classe Modelo. Guarda o conjunto de triangulos que vão produzir
		o objeto tridimensional*/
		Modelo(std::vector<Vertice> vertices);

		/*Funçao get da varivel da classe triangulo*/
		std::vector<Vertice> getVertices();

};