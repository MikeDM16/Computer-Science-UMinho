#pragma once
#include "tinystr.h"
#include "tinyxml.h"

class Orbita {

private:
	float x, y, z, f;
public:
	Orbita();
	Orbita(float x, float y, float z, float f);

	static Orbita Orbita::parseOrbita(TiXmlElement* t);
	float getX();
	float getY();
	float getZ();
	float getF();
};