#include "Parsing.h"
#define _CRT_SECURE_NO_WARNINGS 
// Variaveis globais
/*	Diretoria para o ficheiro xml
Deve ser mudada para cada pc em que se testar
*/
char* dirToXMLFASE3 = "C:\\Users/migue/OneDrive/Trabalho CG/Fase III/sistemaSolar/Ficheiros/";
char* dirToXMLFASE3J = "C:\\Users/gamar/Desktop/Fase II/sistemaSolar/Ficheiros/";
char* dirToXMLFASE3E = "C:\\Users/aniie/Desktop/Fase II/sistemaSolar/Ficheiros/";
char* dirToXMLFASE3N = "C:\\Users/nadin/Desktop/CG/Fase II/sistemaSolar/Ficheiros/";

char diretoriaFicheiro[256];
static std::vector<Grupo> vecGrupos;


void Parsing::imprimeMenu() {
	cout << "\n		Sugestao de interacao com o modelo gerado:\n" <<
		"1. Alteracao do ponto visao da camara\n"
		"   Tecla Up    - Deslocar para cima                Tecla Down - Deslocar para Baixo\n"
		"   Tecla Right - Deslocar para esquerda            Tecla Left - Deslocar para direita\n"
		"2. Opcoes de visualizacao/desenho do modelo\n"
		"   Tecla 1   - So' linhas          Tecla 2  - Preenchido         Tecla 3 - So' vertices\n"
		"3. Movimentacao do modelo\n"
		"   Tecla W - Mover no sentido positivo do eixo Z            Tecla S - Mover no sentido negativo do eixo Z\n"
		"   Tecla A - Mover no sentido positivo do eixo X            Tecla D - Mover no sentido negativo do eixo X\n"
		"4. Animacoes e Zoom\n"
		"   Tecla + - Aumentar o zoom da camara                      Tecla - - Diminuir o zoom da camara\n"
		"   Tecla O - Restaurar todas as definicoes de visualizacao iniciais\n"
		<< endl;
}

vector<Vertice> Parsing::linhaTok(string linha) {
	double x, y, z;
	int i;
	char* verticesStr[3];
	vector<Vertice> vertices;
	/*ler do ficheiro retorna var do tipo string
	strtokanizer usa char* --> converter string p/ char*
	*/
	char *aux = new char[linha.length() + 1];
	strcpy(aux, linha.c_str());

	/*partir a linha pelo caracter ',' ou \n*/
	char* t = strtok(aux, ",\n");
	for (i = 0; t != nullptr; i++) {
		verticesStr[i] = t;
		t = strtok(nullptr, ",\n");;
	}
	/*partir cada vertice, ainda em string, pelo caracter ' ' ou \n*/
	for (i = 0; i != 3; i++) {
		x = atof(strtok(verticesStr[i], " \n"));
		y = atof(strtok(nullptr, " \n"));
		z = atof(strtok(nullptr, " \n"));

		vertices.push_back(Vertice(x, y, z));
	}

	return vertices;
}


Modelo Parsing::lerFicheiro(string fileName) {
	vector<Vertice> vertices, res;
	Modelo m;
	char dirFile[256];
	strcpy(dirFile, diretoriaFicheiro);
	// converter string para char * 
	char * file = new char[fileName.length() + 1];
	strcpy(file, fileName.c_str());

	strcat(dirFile, file);
	cout << "Sera usado o ficheiro na diretoria:\n " << dirFile << endl;

	ifstream inputfile(dirFile);
	if (!inputfile.is_open()) {
		cout << "Nao foi encontrado nenhum ficheiro na diretoria " << dirFile << endl;
	}
	else {
		string linha;
		for (int i = 1; !inputfile.eof(); i++) {
			getline(inputfile, linha);
			/*linha.size()==0 --> linha = null*/
			if (linha.size() != 0) {
				res = Parsing::linhaTok(linha);
				for (auto v : res) {
					vertices.push_back(v);
				}
			}
		}
		m = Modelo::Modelo(vertices);
	}
	inputfile.close();
	return m;
}

Parsing::Parsing(char* fileXml) {
	char dirAux[120];
	strcpy(dirAux, dirToXMLFASE3);
	strcat(dirAux, fileXml);

	TiXmlDocument doc(dirAux);
	if (doc.LoadFile())
	{
		TiXmlNode* root = doc.FirstChildElement("scene");

		// Elemento scene
		TiXmlElement* scene = doc.FirstChildElement("scene");
		// Elemento diretoria e modelo contidos em scene
		TiXmlElement* diretoria = scene->FirstChildElement("diretoria");
		// Elemento grupo contido em scene
		TiXmlElement* rootGrupo = root->FirstChildElement("group");

		//Elemento diretoria tem o atributo dir = caminho at� aos ficheiros
		strcpy(diretoriaFicheiro, (char*)diretoria->Attribute("dir"));

		this->grupoRaiz = new Grupo(rootGrupo);
		Parsing::imprimeMenu();
	}
	else
	{
		cout << "Nao foi possivel abrir o ficheiro XML na diretoria "
			<< dirAux << endl;
	}
}


Grupo* Parsing::getGrupoRaiz() { return this->grupoRaiz; }