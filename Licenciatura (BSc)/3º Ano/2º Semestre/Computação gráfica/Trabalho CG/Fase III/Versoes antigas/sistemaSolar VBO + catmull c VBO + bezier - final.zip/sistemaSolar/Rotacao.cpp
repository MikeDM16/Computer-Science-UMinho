#include "Rotacao.h"

Rotacao::Rotacao() {
	this->time = this->axisX = this->axisY = this->axisZ = 0;
}

Rotacao::Rotacao(double time, int axisX, int axisY, int axisZ) {
	this->time = time;
	this->axisX = axisX;
	this->axisY = axisY;
	this->axisZ = axisZ;
}

Rotacao Rotacao::parseRotacao(TiXmlElement* r) {
	double time;
	int x, y, z;
	if (r != nullptr) {
		time = atof((char*)r->Attribute("time"));
		x = atoi((char*)r->Attribute("axisX"));
		y = atoi((char*)r->Attribute("axisY"));
		z = atoi((char*)r->Attribute("axisZ"));
	}
	else {
		time = x = y = z = 0;
	}

	return Rotacao(time, x, y, z);
}

double Rotacao::getTime() { return this->time; }
int Rotacao::getAxisX() { return this->axisX; }
int Rotacao::getAxisY() { return this->axisY; }
int Rotacao::getAxisZ() { return this->axisZ; }
