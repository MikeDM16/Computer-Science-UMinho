#include "Translacao.h"

Translacao::Translacao(){
	this->time = 0;
	this->vecVertices.push_back(Vertice::Vertice(0, 0, 0));
}

Translacao::Translacao(double time, vector<Vertice> vertices){
	this->time = time; 
	this->vecVertices = vertices; 

}

Translacao Translacao::parseTranslacao(TiXmlElement* t) {
	if (t == nullptr) { return Translacao(); }

	float time, x, y, z;
	vector<Vertice> vecVertices; 

	time = atof((char*) t->Attribute("time"));
	if (time != NULL) {
		TiXmlElement* aux = t->FirstChildElement("point");

		if (time > 0) {
			while (aux) {
				x = atof((char*)aux->Attribute("X"));
				y = atof((char*)aux->Attribute("Y"));
				z = atof((char*)aux->Attribute("Z"));
				vecVertices.push_back(Vertice::Vertice(x, y, z));

				aux = aux->NextSiblingElement("point");
			}
		}
		else {
			//Posi��o est�tica 
			x = atof((char*)aux->Attribute("X"));
			y = atof((char*)aux->Attribute("Y"));
			z = atof((char*)aux->Attribute("Z"));
			vecVertices.push_back(Vertice::Vertice(x, y, z));
		}
	}
	else {
		time = 0;
		vecVertices.push_back(Vertice::Vertice(0, 0, 0));
	}
	return Translacao(time, vecVertices);
}

/* Fun��o auxiliar para a interpola��o dos pontos do catmull*/
void Translacao::getCatmullRomPoint(float t, vector<float> p0, vector<float> p1, vector<float> p2, vector<float> p3, float *res, float *deriv) {
	// reset res and deriv
	for (int i = 0; i < 3; i++) { res[i] = 0.0; deriv[i] = 0.0; }

	//		Matriz Catmull-Rom M 
	vector<vector<float>> elems = { { -0.5f,  1.5f,  -1.5f,  0.5f },
	{ 1.0f, -2.5f,   2.0f, -0.5f },
	{ -0.5f,  0.0f,   0.5f,  0.0f },
	{ 0.0f,  1.0f,   0.0f,  0.0f } };
	Matriz M = Matriz::Matriz(elems);
	elems.clear();
	//		Matriz Catmull-Rom M 

	//		Compute A = M * P
	//Matriz colunas Px, Py e Pz
	Matriz Px = Matriz::Matriz({ { p0[0] },{ p1[0] },{ p2[0] },{ p3[0] } });
	Matriz Py = Matriz::Matriz({ { p0[1] },{ p1[1] },{ p2[1] },{ p3[1] } });
	Matriz Pz = Matriz::Matriz({ { p0[2] },{ p1[2] },{ p2[2] },{ p3[2] } });
	Matriz Ax = M * Px;
	Matriz Ay = M * Py;
	Matriz Az = M * Pz;
	//		Compute A = M * P

	// Matriz T
	elems = { { t*t*t, t*t, t, 1 } };
	Matriz matT = Matriz::Matriz(elems);
	elems.clear();
	// Matriz T

	//		Compute point res = T * A
	float T[4] = { pow(t,3), pow(t,2), t, 1 };

	//		Compute point res = T * A
	Matriz resAux1 = matT * Ax;
	Matriz resAux2 = matT * Ay;
	Matriz resAux3 = matT * Az;

	res[0] = resAux1.getElemento(0, 0);
	res[1] = resAux2.getElemento(0, 0);
	res[2] = resAux3.getElemento(0, 0);

	elems = { { 3 * t*t, 2 * t, 1, 0 } };
	// Matriz T� = derivada T
	Matriz matDerivT = Matriz::Matriz(elems);
	elems.clear();

	Matriz derivAux1 = matDerivT * Ax;
	Matriz derivAux2 = matDerivT * Ay;
	Matriz derivAux3 = matDerivT * Az;

	deriv[0] = derivAux1.getElemento(0, 0);
	deriv[1] = derivAux2.getElemento(0, 0);
	deriv[2] = derivAux3.getElemento(0, 0);
}

void Translacao::getGlobalCatmullRomPoint(float gt, float *res, float *deriv) {

	vector<vector<float>> elems;
	int nrVertices = this->getVecVertices().size(); // n�r de pontos da transla��o.

	vector<Vertice> vertices = this->getVecVertices();
	for (auto v : vertices) {
		elems.push_back({ (float)v.getX(), (float)v.getY(), (float)v.getZ() });
	}

	float t = gt * nrVertices; // this is the real global t
	int index = floor(t);  // which segment
	t = t - index; // where within  the segment

				   // indices store the points
	int indices[4];
	indices[0] = (index + (nrVertices - 1)) % nrVertices;
	for (int j = 0; j < 3; j++) {
		indices[j + 1] = (indices[j] + 1) % nrVertices;
	}

	vector<float> p0 = elems[indices[0]];
	vector<float> p1 = elems[indices[1]];
	vector<float> p2 = elems[indices[2]];
	vector<float> p3 = elems[indices[3]];

	// Executa as interpola��es.
	Translacao::getCatmullRomPoint(t, p0, p1, p2, p3, res, deriv);

}

float Translacao::getTime() { return this->time;  }
vector<Vertice> Translacao::getVecVertices() { return this->vecVertices;  }
