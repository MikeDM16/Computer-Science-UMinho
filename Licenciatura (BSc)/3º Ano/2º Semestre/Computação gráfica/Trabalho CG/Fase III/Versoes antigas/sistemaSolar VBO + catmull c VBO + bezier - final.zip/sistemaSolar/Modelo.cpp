#include <iostream>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <string>
#include "Modelo.h"
#include "Vertice.h"
using namespace std;

#define _USE_MATH_DEFINES 
#include <math.h>

/*Construtor da classe*/
Modelo::Modelo(){}
/*Construtor da classe com parametros*/
Modelo::Modelo(std::vector<Vertice> vertices){
	this->vertices = vertices;
}

std::vector<Vertice> Modelo:: getVertices(){
	return this->vertices;
}

