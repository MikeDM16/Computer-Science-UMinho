#pragma once
#include "tinystr.h"
#include "tinyxml.h"

class Cor {

private:
	float r, g, b;
public:
	Cor();
	Cor(float r, float g, float b);

	static Cor Cor::parseCor(TiXmlElement* c);
	float getR();
	float getG();
	float getB();
};