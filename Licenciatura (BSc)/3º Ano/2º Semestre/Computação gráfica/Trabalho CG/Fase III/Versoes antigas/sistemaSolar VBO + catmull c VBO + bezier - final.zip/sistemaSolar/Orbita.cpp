#include "Orbita.h"

Orbita::Orbita() {
	this->x = this->y = this->z = this->f = 0;
}

Orbita::Orbita(float x, float y, float z, float f) {
	this->x = x;
	this->y = y;
	this->z = z;
	this->f = f;
}

Orbita Orbita::parseOrbita(TiXmlElement* t) {
	float x, y, z, f;
	if (t != nullptr) {
		x = atof((char*)t->Attribute("X"));
		y = atof((char*)t->Attribute("Y"));
		z = atof((char*)t->Attribute("Z"));
		f = atof((char*)t->Attribute("F"));
	}
	else {
		x = y = z = f = 0;
	}

	return Orbita(x, y, z, f);
}

float Orbita::getX() { return this->x; }
float Orbita::getY() { return this->y; }
float Orbita::getZ() { return this->z; }
float Orbita::getF() { return this->f; }