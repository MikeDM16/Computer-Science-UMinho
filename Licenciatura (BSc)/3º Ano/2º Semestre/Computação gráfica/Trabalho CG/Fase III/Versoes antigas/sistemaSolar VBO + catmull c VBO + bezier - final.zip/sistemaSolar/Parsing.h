#pragma once
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>
#include "tinystr.h"
#include "tinyxml.h"
#include <direct.h>
// FASE I 
#include "Vertice.h"
#include "Modelo.h"
// Fase II
#include "Translacao.h"
#include "Escala.h"
#include "Rotacao.h"
#include "Cor.h"
#include "Grupo.h"
#define _CRT_SECURE_NO_WARNINGS 
using namespace std;

class Parsing{
	private:
		class Grupo* grupoRaiz;
		static void Parsing::imprimeMenu();
		static vector<Vertice> Parsing::linhaTok(string linha);
	public:
		Grupo* Parsing::getGrupoRaiz();
		static Modelo Parsing::lerFicheiro(string fileName);
		Parsing::Parsing(char* filexml);
};