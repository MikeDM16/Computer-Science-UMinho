#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <string>
#include <array>
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <direct.h>

#include "Triangulo.h"
#include "Vertice.h"
#include "Matriz.h"
#include "Patch.h"

using namespace std;
#define _USE_MATH_DEFINES 
#include <math.h>

class Modelo{	
	private:
		vector<Triangulo> triangulos;
		static vector<Patch> lerFicheiro(char* file);
	public:
		/*Contrutor padrão */
		Modelo();
		/*Construtor da classe Modelo. Guarda o conjunto de triangulos que vão produzir
		o objeto tridimensional*/
		Modelo(std::vector<Triangulo> trianglinhos);

		/*Funçao get da varivel da classe triangulo*/
		std::vector<Triangulo> getTriangulos();

		/*Funçao responsavel por pegar num Modelo - esfera, caixa, etc - e escreve o seu conjunto 
		de vertice para um ficheiro com o nome especificado no 2º argumento*/
		static void escreveModelo(Modelo m, char * nameFile3d);

		/*Função que dada a medida do lado do quadrado, gera um plano em XZ,
		centrado na origem, feito a partir de um quadrado com 2 triangulos*/
		static void plane(double ladoSqr, char* nameFile3d);

		/*função que dada a largura, comprimento e altura de uma caixa, cria
		as várias faces da caixa usando 2 triangulos por face. */
		static void box(double largura, double compri, double altura, double nDiv, char* nameFile3d);
		
		/*Função que dado o raio, altura, numero de fatias e de stacks, gera os vários vertices que
		darão origem aos triangulos que compoem um cilindro*/
		static void cilindro(double raio, double altura, int fatias, int stacks, char* nameFile3d);

		/*Função que dado o raio, numero de fatias e de stacks, gera os vários vertices que
		darão origem aos triangulos que compoem uma esfera centrada na origem. 
		É usado o conceito de coordenadas esféricas, posteriormente convertidas para cartesianas.*/
		static void sphere(double raio, int fatias, int stacks, char * nameFile3d);
		
		/*Função que dado o raio, altura, numero de fatias e de stacks, gera os vários vertices que
		darão origem aos triangulos que compoem um cone
		É usado o conceito de coordenadas cilindricas, posteriormente convertidas para cartesianas.*/
		static void cone(double raio, double altura, int fatias, int stacks, char* nameFile3d);

		/*Função que dado o ficheiro com as informações de input gera os vertices da figura representada
		pelos patches de Bezier. Recebe como argumentos o char* referente ao ficheiro de input e o inteiro que 
		representa o nivel de tecelagem ("detalhe") a aplicar.*/
		static void bezier(char* file, int tesselation);

};