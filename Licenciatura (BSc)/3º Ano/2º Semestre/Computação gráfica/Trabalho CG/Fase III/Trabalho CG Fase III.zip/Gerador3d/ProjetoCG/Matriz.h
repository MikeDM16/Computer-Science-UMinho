#pragma once
#include <vector>
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <array>
#include "Patch.h"
#define _CRT_SECURE_NO_WARNINGS
using namespace std;

class Matriz {

private:
	int linhas, colunas;
	vector<vector<double>> elementos;
public:
	/*Construtor vazio da classe. Cria uma Matriz sem elementos, com linhs = colunas = 0 */
	Matriz();

	/*Construtor da classe, que recebe como argumento os elementos que v�o compor a matriz*/
	Matriz(vector<vector<double>> elems);

	/*Fun��o que calcula e devolve a Matriz transposta de uma determinada Matriz*/
	Matriz transposta();
	
	/*Defeni��o do operador + (soma) aplicado � classe Matriz. Permite usado o operado + para realizar
	a soma de variaveis do tipo Matriz. ex: M + P */
	Matriz operator+(Matriz m);

	/*Defeni��o do operador * (produto) aplicado � classe Matriz. Permite usado o operado * para realizar
	a soma de variaveis do tipo Matriz. ex: M + P */
	Matriz operator*(Matriz m);

	/*Fun��o que dado o valor de u, v, e a Matriz P, usa a Matriz M pr�definida para gerar a coordenada 
	X, Y, ou Z (conforme a matriz P passada) de um v�tice segundo um patch de Bezier.
	Usa a f�rmula (U * M * matP * M.transposta() * V) */
	static double getPontoB(double u, double v, Matriz P);
	
	/*Fun��o que dado um patch de bezier, com n�mero fixo de 16 vertices, cria a respetiva matriz 4x4 associada ao mesmo.
	Recebe como argumentos o patch a transformar e, no segundo argumento, recebe um parametro que determina se deve usar a
	coordenada X,Y ou Z dos vertices para gerar a matriz.
	Esta matriz resultante ser� usada como matriz P na fun��o getPontoB */
	static Matriz patchToMatriz(Patch p, int cord);
	
	/*Fun��o que devolve o elemento da matriz na posi��o i e j. 
	Recebe como argumento o valor da linha e o valor da coluna, que representam a posi��o do elemento a devolver*/
	double getElemento(int i, int j);
	
	/*Fun��o que devolve todos os elemtos de uma matriz. */
	vector<vector<double>> getElementos();

	/*Fun��o que imprime todos os elementos de uma Matriz. */
	void imprimeMatriz();
	
	/*Fun��o que retorna o n�mero de linhas de uma Matriz*/
	int getLinhas();

	/*Fun��o que devolve o n�mero de colunas de uma Matriz*/
	int getColunas();
};