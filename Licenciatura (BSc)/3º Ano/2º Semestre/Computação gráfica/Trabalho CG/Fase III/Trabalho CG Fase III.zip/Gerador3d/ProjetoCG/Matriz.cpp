#include "Matriz.h"
using namespace std;

Matriz::Matriz() {
	this->elementos = {};
	this->linhas = 0; this->colunas = 0;
}

Matriz::Matriz(std::vector<std::vector<double>> elems) {
	this->linhas = elems.size();

	if (this->linhas > 0) {	this->colunas = elems[0].size(); }
		else {	this->colunas = 0; 	}

	this->elementos = elems;

}

Matriz Matriz::transposta() {
	vector<vector<double>> elems;

	elems = vector<vector<double>>(this->colunas);
	for (int i = 0; i < elems.size(); i++) {
		elems[i] = vector<double>(this->linhas);
	}

	for (int i = 0; i != this->linhas; i++) {
		for (int j = 0; j != this->colunas; j++) {
			elems[j][i] = this->elementos[i][j];
		}
	}

	return Matriz::Matriz(elems);
}

Matriz Matriz::operator+(Matriz m) {
	vector<vector<double>> elems;

	elems = vector<vector<double>>(this->linhas);
	for (int i = 0; i < elems.size(); i++) {
		elems[i] = vector<double>(this->colunas);
	}

	if ((this->linhas != m.getLinhas()) || (this->colunas != m.getColunas())) {
		cout << "Nao e possivel somar as matrizes. Dimensoes erradas." << endl;
	}
	else {
		for (int i = 0; i != this->linhas; i++) {
			for (int j = 0; j != this->colunas; j++) {
				elems[j][i] = this->elementos[i][j] + m.getElemento(i, j);
			}
		}
	}

	return Matriz::Matriz(elems);
}

Matriz Matriz::operator*(Matriz m) {

	if (this->colunas != m.getLinhas()) {
		cout << "Nao e possivel multiplicar as matrizes. Dimensoes erradas." << endl;
	}
	
	vector<vector<double>> elems = vector<vector<double>>(this->linhas);
	for (int i = 0; i < elems.size(); i++) {
		elems[i] = vector<double>(m.getColunas());
	}
	for (int i = 0; i < this->linhas; i++) {
		for (int j = 0; j < m.getColunas(); j++) {
			double soma = 0.0;
			for (int k = 0; k < this->colunas; k++) {
				soma += this->elementos[i][k] * m.getElemento(k, j);
			}

			elems[i][j] = soma;
		}
	}
	return Matriz::Matriz(elems);
}

double Matriz::getElemento(int i, int j) {
	double r = 0.0;
	if ((i <= this->linhas) && (j <= this->colunas)) {
		r = this->elementos[i][j];
	}
	return r;
}

double Matriz::getPontoB(double u, double v, Matriz matP) {
	vector<vector<double>> elems = { { -1,   3, -3,  1 },
							    	 {  3,  -6,  3,  0 },
									 { -3,   3,  0,  0 },
									 {  1,   0,  0,  0 } };
	Matriz M = Matriz(elems);
	elems.clear();

	elems = { { u * u * u, u * u, u, 1 } };
	Matriz U = Matriz(elems);
	elems.clear();

	elems = { { v * v * v },
			  { v * v },
			  { v },
			  { 1 } };
	Matriz V = Matriz(elems);
	elems.clear();

	double r = (U * M * matP * M.transposta() * V).getElemento(0, 0);
	return r;
}

Matriz Matriz::patchToMatriz(Patch p, int cord) {
	vector<vector<double>> elems;
	int i,j;
	elems = vector<vector<double>>(4);
	for (i = 0; i < 4; i++) {
		elems[i] = vector<double>(4);
	}

	if (cord == 1) {
		for (j = 0, i = 0; i < 4; i++, j+=4) {
			elems[i] = { p.getVert(j).getX(), p.getVert(j + 1).getX(), p.getVert(j + 2).getX(), p.getVert(j + 3).getX() };
		}
	}
	if (cord == 2) {
		for (j = 0, i = 0; i < 4; i++, j+=4) {
			elems[i] = { p.getVert(j).getY(), p.getVert(j + 1).getY(), p.getVert(j + 2).getY(), p.getVert(j + 3).getY() };
		}
	}
	if (cord == 3) {
		for (j = 0, i = 0; i < 4; i++, j+=4) {
			elems[i] = { p.getVert(j).getZ(), p.getVert(j + 1).getZ(), p.getVert(j + 2).getZ(), p.getVert(j + 3).getZ() };
		}
	}
	
	Matriz mat = Matriz::Matriz(elems);
	return mat;
}

int Matriz::getLinhas() { return this->linhas;  }
int Matriz::getColunas() { return this->colunas;  }
vector<vector<double>> Matriz::getElementos() { return this->elementos; }

void Matriz::imprimeMatriz() {
	cout << "Matriz\n";
	for (int i = 0; i < this->linhas; i++) {
		for (int j = 0; j < this->colunas; j++) {
			cout << "Elemento[" << i << "][" << j << "]= " 
				 << this->elementos[i][j] << ",  ";
		}
		cout << endl;
	}
}