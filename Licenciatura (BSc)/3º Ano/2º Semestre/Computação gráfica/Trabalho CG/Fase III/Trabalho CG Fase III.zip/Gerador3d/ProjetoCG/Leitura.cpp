#include "Leitura.h"
#include <iostream>
#include <fstream>
using namespace std;

char* dir2patch = "C:\\Users/migue/OneDrive/Trabalho CG/Fase II/sistemaSolar/Ficheiros/";
char* dir2patchJ = "C:\\Users/gamar/Desktop/Fase II/sistemaSolar/Ficheiros/";
char* dir2patchE = "C:\\Users/aniie/Desktop/Fase II/sistemaSolar/Ficheiros/";
char* dir2patchN = "C:\\Users/nadin/Desktop/CG/Fase II/sistemaSolar/Ficheiros/";
char diretoriaFicheiro[256];

vector<Patch> lerFicheiro(char* file) {
	char dirFile[256];
	strcpy(dirFile, dir2patch);

	strcat(dirFile, file);
	cout << "Sera usado o ficheiro na diretoria:\n " << dirFile << endl;

	ifstream inputfile(dirFile);
	if (!inputfile.is_open()) {
		cout << "Nao foi encontrado nenhum ficheiro na diretoria " << dirFile << endl;
	}


}