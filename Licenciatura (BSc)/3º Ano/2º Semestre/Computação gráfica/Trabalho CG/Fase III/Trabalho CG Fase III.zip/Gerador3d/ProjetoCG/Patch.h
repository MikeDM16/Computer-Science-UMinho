#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <cstdlib>
#include <array>
#include <cstdlib>
#include <fstream>

#include "Vertice.h"
using namespace std;

class Patch {
	private:
		array<Vertice, 16> vertices;
	public:
		/*Construtor padr�o da classe Patch. Inicia a sua variavel com um array vazio*/
		Patch();
		
		/*Fun��o que retorna um determinado vertice, na posi��o i, do array de vertices da variavel da classe
		Recebe como argumento o inteiro que representa o indice a devolver*/
		Vertice getVert(int i);
		
		/*Fun��o que devolve a variavel global da classe: array de 16 vertices (Patch)*/
		array<Vertice, 16> getVertices();
		
		/*Fun��o que coloca no indice 'i' da varivavel global um determinado Vertice. 
		Recebe como argumentos o indice i e o vertice a copiar para o respetivo indice*/
		void setVertice(int i, Vertice v);
};