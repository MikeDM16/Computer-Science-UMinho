#include "Matriz.h"
using namespace std;

Matriz::Matriz() {
	this->elementos = {};
	this->linhas = 0; this->colunas = 0;
}

Matriz::Matriz(std::vector<std::vector<float>> elems) {
	this->linhas = elems.size();

	if (this->linhas > 0) {	this->colunas = elems[0].size(); }
		else {	this->colunas = 0; 	}

	this->elementos = elems;

}

Matriz Matriz::transposta() {
	vector<vector<float>> elems;

	elems = vector<vector<float>>(this->colunas);
	for (int i = 0; i < elems.size(); i++) {
		elems[i] = vector<float>(this->linhas);
	}

	for (int i = 0; i != this->linhas; i++) {
		for (int j = 0; j != this->colunas; j++) {
			elems[j][i] = this->elementos[i][j];
		}
	}

	return Matriz::Matriz(elems);
}

Matriz Matriz::operator+(Matriz m) {
	vector<vector<float>> elems;

	elems = vector<vector<float>>(this->linhas);
	for (int i = 0; i < elems.size(); i++) {
		elems[i] = vector<float>(this->colunas);
	}

	if ((this->linhas != m.getLinhas()) || (this->colunas != m.getColunas())) {
		cout << "Nao e possivel somar as matrizes. Dimensoes erradas." << endl;
	}
	else {
		for (int i = 0; i != this->linhas; i++) {
			for (int j = 0; j != this->colunas; j++) {
				elems[j][i] = this->elementos[i][j] + m.getElemento(i, j);
			}
		}
	}

	return Matriz::Matriz(elems);
}

Matriz Matriz::operator*(Matriz m) {

	if (this->colunas != m.getLinhas()) {
		cout << "Nao e possivel multiplicar as matrizes. Dimensoes erradas." << endl;
	}
	
	vector<vector<float>> elems = vector<vector<float>>(this->linhas);
	for (int i = 0; i < elems.size(); i++) {
		elems[i] = vector<float>(m.getColunas());
	}
	for (int i = 0; i < this->linhas; i++) {
		for (int j = 0; j < m.getColunas(); j++) {
			double soma = 0.0;
			for (int k = 0; k < this->colunas; k++) {
				soma += this->elementos[i][k] * m.getElemento(k, j);
			}

			elems[i][j] = soma;
		}
	}
	return Matriz::Matriz(elems);
}

double Matriz::getElemento(int i, int j) {
	double r = 0.0;
	if ((i <= this->linhas) && (j <= this->colunas)) {
		r = this->elementos[i][j];
	}
	return r;
}

int Matriz::getLinhas() { return this->linhas;  }
int Matriz::getColunas() { return this->colunas;  }
vector<vector<float>> Matriz::getElementos() { return this->elementos; }

void Matriz::imprimeMatriz() {
	cout << "Matriz\n";
	for (int i = 0; i < this->linhas; i++) {
		for (int j = 0; j < this->colunas; j++) {
			cout << "Elemento[" << i << "][" << j << "]= " 
				 << this->elementos[i][j] << ",  ";
		}
		cout << endl;
	}
}