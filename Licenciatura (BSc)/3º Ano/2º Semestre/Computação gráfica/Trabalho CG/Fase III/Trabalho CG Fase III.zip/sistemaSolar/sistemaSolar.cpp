#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <cmath>
#include <GL/glew.h>
#include <GL/glut.h>
#endif

#include "sistemaSolar.h"
#define _CRT_SECURE_NO_WARNINGS 
#define _USE_MATH_DEFINES
#include <math.h>

using namespace std;

Parsing* parsingXML;
Grupo* grupos;
std::vector<Grupo> vecGrupos;
GLuint* VBO_Modelos;
GLuint* VBO_CatmullRon;
int nrCatmullRoms;
int nrModelos, ind_atual = 0, ind_atualAux = 0;

/*Variaveis para a fun��o de FPS*/
int frame = 0, time, timebase = 0, fps;

// angle of rotation for the camera direction
float angleX = 0.0f;
float angleY = 0.0f;
float angleZ = 0.0f;
float beta = -20.0f;

// Straight line distance between the camera and look at point
float rCam = 350.0f;
float xxx = 0.0f;
float zzz = 0.0f;
float yyy = 0.0f;

int comodesenha = 2;
float alpha = 0.0f;


void changeSize(int w, int h) {

	// Prevent a divide by zero, when window is too short
	// (you cant make a window with zero width).
	if (h == 0)
		h = 1;

	// compute window's aspect ratio 
	float ratio = w * 1.0 / h;

	// Set the projection matrix as current
	glMatrixMode(GL_PROJECTION);
	// Load Identity Matrix
	glLoadIdentity();

	// Set the viewport to be the entire window
	glViewport(0, 0, w, h);

	// Set perspective
	gluPerspective(45.0f, ratio, 1.0f, 1000.0f);

	// return to the model view matrix mode
	glMatrixMode(GL_MODELVIEW);
}

float size = 1;

void preencheVBOsModelos(Grupo* grupos) {
	int iter = 0;
	vector<Modelo> modelos = grupos->getVecModels();
	for (auto modelo : modelos) {

		vector<Vertice> vertsModelo = modelo.getVertices();
		/*Cada v�rtice tem 3 coordenadas */
		int size = 3 * vertsModelo.size();
		double* vecCoordenadas = new double[size];

		for (auto vertice : vertsModelo) {
			vecCoordenadas[iter++] = vertice.getX();
			vecCoordenadas[iter++] = vertice.getY();
			vecCoordenadas[iter++] = vertice.getZ();
		}

		/*Tornar ativo o buffer que vai ter as coordenadas dos vertices do modelo atual*/
		glBindBuffer(GL_ARRAY_BUFFER, VBO_Modelos[ind_atual]);
		/*Preencher o buffer com os v�rtices do modelo atual*/
		glBufferData(GL_ARRAY_BUFFER, size * sizeof(double), vecCoordenadas, GL_STATIC_DRAW);

		/*Incrementar o indice do buffer, para que o proximo modelo lido fique guardado
		na proxima posi��o do array de VBOs. */
		ind_atual++;

		/*Se um grupo tiver descendencia, esta deve ser adicionada primeiro �
		estrutura dos VBOs*/
		Grupo* aux = grupos->getFilho();
		if (aux) { preencheVBOsModelos(aux); }

		/*Depois de analisar se tem filhos, s� depois podem ser adicionados os irmaos
		� estrutura de dados com os VBOs*/
		aux = grupos->getIrmao();
		if (aux) { preencheVBOsModelos(aux); }
	}
}
void preencheVBOsCatmullRom(Grupo* grupos) {
	int iter = 0;
	Translacao trans = grupos->getT();
	if ((trans.getTime() > 0) && (trans.getVecVertices().size() >= 4)) {
		float res[3], deriv[3];
		vector<Vertice> vertsCatmullRom;
		double* vecCoordenadas;	int size;
		int nrVert = 0;
		//Se tem trnaslacao, ir buscar os pontos da linha da catmull-rom - renderCatmull-rom
		for (float gt = 0.0; gt < 1; gt += 0.01) {
			trans.getGlobalCatmullRomPoint(gt, res, deriv);
			vertsCatmullRom.push_back(Vertice::Vertice(res[0], res[1], res[2]));
			nrVert++; 
		}
		/*Cada v�rtice tem 3 coordenadas */
		size = 3 * vertsCatmullRom.size();
		vecCoordenadas = new double[size];
		for (auto vertice : vertsCatmullRom) {
			vecCoordenadas[iter++] = vertice.getX();
			vecCoordenadas[iter++] = vertice.getY();
			vecCoordenadas[iter++] = vertice.getZ();
		}
	
		/*Tornar ativo o buffer que vai ter as coordenadas dos vertices da curva de catmull*/
		glBindBuffer(GL_ARRAY_BUFFER, VBO_CatmullRon[ind_atualAux]);
		/*Preencher o buffer com os v�rtices da curva atual calculada*/
		glBufferData(GL_ARRAY_BUFFER, size * sizeof(double), vecCoordenadas, GL_STATIC_DRAW);

		/*Incrementar o indice do buffer, para que o proxima curva lida fique guardado
		na proxima posi��o do array de VBOs. */
		ind_atualAux++;
	}
	
	/*Se um grupo tiver descendencia, esta deve ser adicionada primeiro �
	estrutura dos VBOs*/
	Grupo* aux = grupos->getFilho();
	if (aux) { preencheVBOsCatmullRom(aux); }

	/*Depois de analisar se tem filhos, s� depois podem ser adicionados os irmaos
	� estrutura de dados com os VBOs*/
	aux = grupos->getIrmao();
	if (aux) { preencheVBOsCatmullRom(aux); }
}

void countFPS() {
	frame++;
	time = glutGet(GLUT_ELAPSED_TIME);
	if (time - timebase > 1000) {
		double fps = (frame*1000.0 / (time - timebase));
		auto str = std::to_string(fps);
		glutSetWindowTitle(str.c_str());
		timebase = time;
		frame = 0;
	}
}

void renderCatmullRomCurve(Translacao t) {
	float res[3], deriv[3];

	glBegin(GL_LINE_LOOP);
	for (float gt = 0.0; gt < 1; gt += 0.01) {
		t.getGlobalCatmullRomPoint(gt, res, deriv);
		glVertex3f(res[0], res[1], res[2]);
	}
	glEnd();
}

void desenhaGrupos(Grupo *g) {
	Translacao trans = g->getT(); Rotacao rot = g->getR();	Escala esc = g->getE();
	vector<Modelo> vecModelos = g->getVecModels(); Cor c = g->getCor(); 
	double time; float x, y, z, f;
	vector<Vertice> vertices;
	
	glPushMatrix();

	/*Realizar transla��o    CATMULL-RON HERE
	S�o precisos pelo menos 4 pontos e o tempo deve ser > 0 */
	if ( (trans.getTime()>0) && (trans.getVecVertices().size() >= 4)) {
		float res[3], deriv[3];
		float t = glutGet(GLUT_ELAPSED_TIME) % ((int) trans.getTime() * 1000);
		float gt = t / (trans.getTime() * 1000);

		/*Desenhar linha que o objeto segue
		VBOS substituem a chamada da renderCatmullRomCurve(trans); */
		glBindBuffer(GL_ARRAY_BUFFER, VBO_CatmullRon[ind_atualAux]);
		glVertexPointer(3, GL_DOUBLE, 0, 0);
		
		//Cor da linha = cor do planete
		glColor3f(c.getR(), c.getG(), c.getB());

		/*sem lista de indices - desenhar os segmentos de reta da linha */
		glDrawArrays(GL_LINE_LOOP, 0, 101 );

		ind_atualAux++;
		if (ind_atualAux == nrCatmullRoms) { ind_atualAux = 0; }

		//Por o mo�o a andar sobre a linha, durante o tempo especificado no xml
		trans.getGlobalCatmullRomPoint(gt, res, deriv);
		glTranslatef(res[0], res[1], res[2]);
	}
	else {
		// translacao est�tica
		vector<Vertice> v = trans.getVecVertices();
		glTranslatef(v.at(0).getX(), v.at(0).getY(), v.at(0).getZ());
	}

	//realizar escala
	x = esc.getX(); y = esc.getY(); z = esc.getZ();
	glScalef(x, y, z);

	//realizar rota��es, apenas se o valor de time for superior a 0 segundos
	time = rot.getTime() * 360; x = rot.getAxisX(); y = rot.getAxisY(); z = rot.getAxisZ();
	if (time > 0) {
		double alpha = (double)glutGet(GLUT_ELAPSED_TIME) / time;
		glRotatef(alpha, x, y, z);
	}
	//desenhar modelos
	for (Modelo modelo : vecModelos) {
		glBindBuffer(GL_ARRAY_BUFFER, VBO_Modelos[ind_atual]);
		glVertexPointer(3, GL_DOUBLE, 0, 0);
		
		glColor3f(c.getR(), c.getG(), c.getB());
		
		/*sem lista de indices */
		glDrawArrays(GL_TRIANGLES, 0, modelo.getVertices().size()); 

		ind_atual++;
		if (ind_atual == nrModelos) { ind_atual = 0; }

	}//Fim desenhar Modelos
	 
	Grupo* aux = g->getFilho();
	if (aux) {
		desenhaGrupos(aux);
	}

	glPopMatrix();
	
	aux = g->getIrmao();
	if (aux) {
		desenhaGrupos(aux);
	}
}

void renderScene(void) {
	// clear buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	float cX = rCam * -sinf((alpha)*(M_PI / 180)) * cosf((beta)*(M_PI / 180));
	float cY = rCam * -sinf((beta)*(M_PI / 180));
	float cZ = -rCam * cosf((alpha)*(M_PI / 180)) * cosf((beta)*(M_PI / 180));

	// Set the camera position and lookat point
	gluLookAt(cX, cY, cZ,   // Camera position
		0.0, 0.0, 0.0,    // Look at point
		0.0, 1.0, 0.0);   // Up vector;
	// Put the geometric transformations here
	if (comodesenha == 1) glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	if (comodesenha == 2) glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	if (comodesenha == 3) glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
	glRotatef(angleY, 0, 1, 0);
	glRotatef(angleX, 1, 0, 0);
	glRotatef(angleZ, 0, 0, 1);
	glTranslatef(xxx, yyy, zzz);
	
	// put drawing instructions here
	/*Colocar o indice a 0, porque a desenha grupos itera todos os VBOs 
	e deve come�ar no VBO[0], � medida que simultaneamente itera os modelos*/
	ind_atual = 0;
	desenhaGrupos( grupos );
	
	countFPS();

	glEnd();

	// End of frame
	glutSwapBuffers();
}

// write function to process keyboard events
void arrows(int key_code, int xx, int yy) {
	//frac��o em que v�o aumentar os angulos
	float fraction = 0.9f;
	switch (key_code) {
	case GLUT_KEY_LEFT:
		alpha += fraction;
		break;
	case GLUT_KEY_RIGHT:
		alpha -= fraction;
		break;
	case GLUT_KEY_DOWN:
		if (abs((beta + fraction)*(M_PI / 180))<1.5)
			beta += fraction;
		break;
	case GLUT_KEY_UP:
		if (abs((beta - fraction)*(M_PI / 180))<1.5)
			beta -= fraction;
		break;
	}
	glutPostRedisplay();
};
/*Fun��o que atribui a fun��o de zoom �s teclas + e -, aumentando e diminuindo 
o zoom da camara, sem exceder a distancia de zoom maxima*/
void normalkeyboard(unsigned char tecla, int x, int y) {
	switch (tecla) {
	case '+': if (rCam > 1.0f) rCam -= 1.0f; break;
	case '-':  rCam += 1.0f; break;
	case 'w':  zzz -= 1.0f; break;
	case 'a':  xxx -= 1.0f; break;
	case 's':  zzz += 1.0f; break;
	case 'd':  xxx += 1.0f; break;
	case 't':  yyy -= 1.0f; break;
	case 'g':  yyy += 1.0f; break;
	case '1':  comodesenha = 1; break;
	case '2':  comodesenha = 2; break;
	case '3':  comodesenha = 3; break;
	case 'y':  angleX += 0.5f; break;
	case 'h':  angleX -= 0.5f; break;
	case 'u':  angleY += 0.5f; break;
	case 'j':  angleY -= 0.5f; break;
	case 'i':  angleZ += 0.5f; break;
	case 'k':  angleZ -= 0.5f; break;
	case 'o':  rCam = 350.0f;
			   angleX = 0; angleY = 0; angleZ = 0;
			   alpha = 0; beta = -20;
			   xxx = 0; yyy = 0; zzz = 0;
			   break;
	}

	glutPostRedisplay();
}



int main(int argc, char **argv) {

	if (argc == 1) { parsingXML = new Parsing("input.xml"); }
	else
	parsingXML = new Parsing(argv[1]);
	grupos = parsingXML->getGrupoRaiz();

	// put GLUT init here
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(1000, 800);
	glutCreateWindow("Trabalho Computa��o Gr�fica - Fase 3");

	// put callback registration here
	glutDisplayFunc(renderScene);
	glutReshapeFunc(changeSize);
	glutIdleFunc(renderScene);

	// put here the registration of the keyboard callbacks
	glutSpecialFunc(arrows);
	glutKeyboardFunc(normalkeyboard);

	#ifndef __APPLE___
		glewInit();
	#endif

	// OpenGL settings 
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	//Cor cinzenta;
	glClearColor(0.098, 0.098, 0.439, 1.0f);

	/*Determinar quantos modelos forma lidos do input e 
	existem para renderizar. Existe um VBO para cada modelo	*/
	nrModelos = grupos->getNrModelos();
	VBO_Modelos = new GLuint[nrModelos];
	/*Gerar um buffer de vertices*/
	glGenBuffers(nrModelos, VBO_Modelos);


	nrCatmullRoms = grupos->getNrCatmullRoms();
	VBO_CatmullRon = new GLuint[nrCatmullRoms];
	glGenBuffers(nrCatmullRoms, VBO_CatmullRon);

	preencheVBOsModelos(grupos);
	preencheVBOsCatmullRom(grupos);

	ind_atual = 0;
	ind_atualAux = 0;

	glEnableClientState(GL_VERTEX_ARRAY);
	
	// enter GLUT's main loop
	glutMainLoop();

	return 1;
}

