#include "Escala.h"

Escala::Escala(){
	this->x = this->y = this->z = 0;
}

Escala::Escala(float x, float y, float z){
	this->x = x;
	this->y = y;
	this->z = z;
}

Escala Escala::parseEscala(TiXmlElement* e) {
	float x, y, z;
	if (e != nullptr) {
		x = atof((char*)e->Attribute("X"));
		y = atof((char*)e->Attribute("Y"));
		z = atof((char*)e->Attribute("Z"));
	}
	else {
		x = y = z = 1;
	}

	return Escala(x, y, z);
}

float Escala::getX(){ return this->x; }
float Escala::getY(){ return this->y; }
float Escala::getZ(){ return this->z; }
