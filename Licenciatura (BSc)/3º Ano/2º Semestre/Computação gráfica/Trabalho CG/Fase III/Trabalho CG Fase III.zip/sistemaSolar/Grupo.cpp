#pragma once
#include "Grupo.h"

Grupo::Grupo(Rotacao R, Translacao T, Escala E, Cor c, vector<Modelo> modelos, Grupo* irmao, Grupo* filho) {
	this->vecModels = modelos;
	this->R = R; this->T = T; this->E = E; this->c = c;
	this->irmao = irmao; this->filho = filho;
}

Grupo::Grupo(TiXmlElement* rootGrupo) {

	TiXmlElement* translacao, *rotacao, *escala, *modelos, *modelo, *cores;
	translacao = rootGrupo->FirstChildElement("translate");
	escala = rootGrupo->FirstChildElement("scale");
	rotacao = rootGrupo->FirstChildElement("rotate");
	modelos = rootGrupo->FirstChildElement("models");
	modelo = modelos->FirstChildElement("model");
	cores = rootGrupo->FirstChildElement("cor");

	this->T = Translacao::parseTranslacao(translacao);
	this->R = Rotacao::parseRotacao(rotacao);
	this->E = Escala::parseEscala(escala);
	this->c = Cor::parseCor(cores);
	for (modelo = modelos->FirstChildElement("model"); modelo != nullptr; modelo = modelo->NextSiblingElement("model")) {
		string file = (char*)modelo->Attribute("file");
		this->vecModels.push_back( Parsing::lerFicheiro(file) );
	}

	TiXmlElement* aux = rootGrupo->FirstChildElement("group");
	if (aux) {
		this->filho = new Grupo(aux);
	}
	else {
		this->filho = nullptr;
	}
	aux = rootGrupo->NextSiblingElement("group");
	if (aux) {
		this->irmao = new Grupo(aux);
	}
	else {
		this->irmao = nullptr;
	}
}

Rotacao Grupo::getR() { return this->R; }
Translacao Grupo::getT() { return this->T; }
Escala Grupo::getE() { return this->E; }
Cor Grupo::getCor() { return this->c;  }
vector<Modelo> Grupo::getVecModels() { return this->vecModels; }
Grupo* Grupo::getFilho() { return this->filho; }
Grupo* Grupo::getIrmao() { return this->irmao; }
int Grupo::getNrModelos() { 
	int r = 0;
	r = this->getVecModels().size();

	Grupo* aux = this->getFilho();
	if (aux) { r += aux->getNrModelos(); }

	aux = this->getIrmao();
	if (aux) { r += aux->getNrModelos(); }

	return r;
}
int Grupo::getNrCatmullRoms() {
	int r = 0;
	Translacao trans = this->T; 
	if ((trans.getTime() > 0) && (trans.getVecVertices().size() >= 4)) {
		r++;
	}

	Grupo* aux = this->getFilho();
	if (aux) { r += aux->getNrCatmullRoms(); }

	aux = this->getIrmao();
	if (aux) { r += aux->getNrCatmullRoms(); }

	return r;
}
