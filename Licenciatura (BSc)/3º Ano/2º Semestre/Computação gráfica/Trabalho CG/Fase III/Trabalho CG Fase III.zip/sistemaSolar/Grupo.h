#pragma once
#include <iostream>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <string>
#include "Modelo.h"
#include "Translacao.h"
#include "Rotacao.h"
#include "Escala.h"
#include "Cor.h"
#include "tinystr.h"
#include "tinyxml.h"
#include <direct.h>
#include "Parsing.h"

using namespace std;

class Grupo{
	private:
		Rotacao R; 
		Translacao T; 
		Escala E;
		Cor c;
		vector<Modelo> vecModels;
		Grupo* irmao, *filho;

	public:
		Grupo::Grupo(Rotacao R, Translacao T, Escala E, Cor c, vector<Modelo> modelos, Grupo* irmao =nullptr, Grupo *filho = nullptr);
		Grupo::Grupo(TiXmlElement* raizGrupo);
		Rotacao Grupo::getR();
		Translacao Grupo::getT();
		Escala Grupo::getE();
		Cor Grupo::getCor();
		vector<Modelo> Grupo::getVecModels();
		Grupo* Grupo::getFilho();
		Grupo* Grupo::getIrmao();
		int getNrModelos();
		int getNrCatmullRoms();
};