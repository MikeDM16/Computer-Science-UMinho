#pragma once
#include "tinystr.h"
#include "tinyxml.h"
#include <vector>
#include "Matriz.h"
#include "Vertice.h"
using namespace std;

class Translacao {

private:
	float time;
	vector<Vertice> vecVertices; 
public:
	Translacao();
	Translacao::Translacao(double time, vector<Vertice> vertices);
	static Translacao Translacao::parseTranslacao(TiXmlElement* t);
	void Translacao::getCatmullRomPoint(float t, vector<float> p0, vector<float> p1, vector<float> p2, vector<float> p3, float *res, float *deriv);
	void Translacao::getGlobalCatmullRomPoint(float gt, float *res, float *deriv);
	float getTime();
	vector<Vertice> getVecVertices();
};