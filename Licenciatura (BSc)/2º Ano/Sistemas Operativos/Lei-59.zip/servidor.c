#define _GNU_SOURCE 
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>

#define MAX_SIZE1 1024
#define MAX_SIZE2 512


int limpar(char* data, char* metadata){
	/* declaração das variaveis */
	int  i, n, fd, pd[2];
	char resData[MAX_SIZE1], resMData[MAX_SIZE1], buff[MAX_SIZE1];
	char destData[MAX_SIZE1], destMData[MAX_SIZE1];
	char *executar[MAX_SIZE1];
	char *sha1sumCodesData[MAX_SIZE1], *nomesMData[MAX_SIZE1], *sha1sumCodesMData[MAX_SIZE1]; 
	char *p;
	
	puts("--- Limpar info ---");

	/* Colocar a variavel passada como argumento, com o destino para a pasta /data, na variavel da funcao destData */
	strcpy(destData, data);
	/* Colocar "/" no final da string que tem a diretoria da pasta /data, para que funcione nos exec */
	strcat(destData, "/");
	/* Colocar a variavel passada como argumento, com o destino para a pasta /metadata, na variavel da funcao destData */
	strcpy(destMData, metadata);
	/* Colocar "/" no final da string que tem a diretoria da pasta /metada, para que funcione nos exec */
	strcat(destMData, "/");
   
  	pipe(pd);
	if(fork()==0) {
		close(pd[0]);
		dup2(pd[1], 1); close(pd[1]);
		executar[0] = (char*) malloc(3*sizeof(char));
		strcpy(executar[0], "ls");
		executar[1] = (char*) malloc(strlen(destData)*sizeof(char));
		strcpy(executar[1], destData);
		executar[2]=NULL;
		execvp("ls", executar); 
		perror("ls");
		_exit(1);
	}
	else {
		wait(NULL);
		read(pd[0], resData, sizeof(resData));
		close(pd[0]); close(pd[1]);
		}

	p = strtok(resData, "\n\0");
	for(i=0; p!=NULL; i++){
		sha1sumCodesData[i]= (char*) malloc((strlen(p))*sizeof(char));
		strcpy(sha1sumCodesData[i], p);
		p = strtok(NULL, "\n\0");
	}
	sha1sumCodesData[i]=NULL;

	for(i=0; sha1sumCodesData[i]!=NULL; i++)
		printf("codigos sha1sum data: %s\n",sha1sumCodesData[i]);


	pipe(pd);
	if(fork()==0) {
		close(pd[0]);
		dup2(pd[1], 1); close(pd[1]);
		executar[0] = (char*) malloc(3*sizeof(char));
		strcpy(executar[0], "ls");
		executar[1] = (char*) malloc(strlen(destMData)*sizeof(char));
		strcpy(executar[1], destMData);
		executar[2] =NULL;
		execvp("ls", executar); 
		perror("ls");
		_exit(1);
	}
	else {
		wait(NULL);
		read(pd[0], resMData, sizeof(resMData));
		close(pd[0]); close(pd[1]);
		}

	p = strtok(resMData, "\n\0");
	for(i=0; p!=NULL; i++){
		nomesMData[i]= (char*) malloc((strlen(p))*sizeof(char));
		strcpy(nomesMData[i], p);
		p = strtok(NULL, "\n\0");
	}
	nomesMData[i]=NULL;

	for(i=0; nomesMData[i]!=NULL; i++)
		printf("nomes metadata   :%s\n",nomesMData[i]);


	for(i=0; nomesMData[i]!=NULL; i++){
		strcpy(destMData, metadata);
		strcat(destMData, "/");
		strcat(destMData, nomesMData[i]);
		printf("destino meta data:  %s\n",destMData);
		
		fd = open(destMData, O_RDONLY);
		perror(destMData);
		n = read(fd, buff, sizeof(buff));
		sha1sumCodesMData[i] = (char*) malloc((n)*sizeof(char));
		strcpy(sha1sumCodesMData[i], buff);
		/*strcat(sha1sumCodesMData[i], ".gz");*/
	}

	for(i=0; sha1sumCodesMData[i]!=NULL; i++)
		printf("codigos sha1sum metadata: %s\n",sha1sumCodesMData[i]);

	return 0;

}

int delete(char* comando[], char* data, char* metadata){
	/* declaração das variaveis */
	char *file, *sha1sumCode;
	int i, n, pd[2];
	char res[MAX_SIZE1], destData[MAX_SIZE2], destMData[MAX_SIZE2];
	char* ficheiros[MAX_SIZE2], *executar[MAX_SIZE2];

	/*Aplicar o comando sha1sum a todos os ficheiros que se deseja apagar;
	O nome dos ficheiros é recebido como argumento à funçao delete;
	*/
	pipe(pd);
	/* Por forma a reaver o resultado devolvido pelo sha1sum aplicado aos argumentos, é
	criado um pipe anónimo e redirecionada a entrada do pipe (pd[1]) para a saida do standart output
	perdefinida, usando a funcao dup2 */
	/* fork para obter o sha1sum, executado num execvp, dos ficheiros dados como argumento*/
	if(fork()==0) {
		close(pd[0]);
		dup2(pd[1], 1); close(pd[1]);
		comando[0] = (char*) malloc(8*sizeof(char));
		strcpy(comando[0], "sha1sum");
		execvp("sha1sum", comando); 
		perror("sha1sum");
		_exit(1);
	}else {
		wait(NULL);
		/*Ler o resultado devolvido pelo fork, atravez do refirecionamento da standart output
		para a entrada do pipe anonimo pd. --> Ler da entrada do pipe = ler em pd[0]*/
		read(pd[0], res, sizeof(res));
		close(pd[0]); close(pd[1]);
	}

	/* O resutaldo do fork anterior será uma string com uma string do tipo:
		"sha1sum1 file1Name\n sha1sum2 file2Name\n (...) sha1sumN fileNName\n\0"
		Está string é então, inicialmente, partida pelos "\n" com o strtok e colocada num array de string*/
	file = strtok(res, "\n"); 
	for(i=0; file!=NULL; i++){
		ficheiros[i]= (char*) malloc(strlen(file)*sizeof(char));
		strcpy(ficheiros[i], file);
		file = strtok(NULL, "\n");
	}
	ficheiros[i]=NULL;

	/* Em seguida, para cada string do tipo "sha1sumCode fileName", esta é partifa pelo
	caracter " " (espaço) para obter apenas o codigo sha1sum do ficheiro correspondente.
	O ficheiro do codigo obtido é o ficheiro na posiçao comando[i+1] (a primeira posicao do array
	de strings comando tem a string "delete"*/
	for(i=0; ficheiros[i]!=NULL; i++){
		puts("--- Remoçao do ficheiro ---");
		n = open(comando[i+1], O_RDONLY);
		if(n!=-1){
			printf("Ficheiro a apagar: %s\n",comando[i+1]);
			/*obter o codigo sha1sum */
			sha1sumCode = strtok(ficheiros[i], " ");
			/*printf("Sha1sumCode: %s\n", sha1sumCode);*/
			strcpy(destData, data); 
			strcat(destData, "/");
			/*concatenar à string com a diretoria para a pasta /data o codigo sha1sum do ficheiro 
			a fazer backup*/
			strcat(destData, sha1sumCode);
			/*adicionar a extençao ao ficheiro*/
			strcat(destData, ".gz");
			/*criar uma string com a diretoria para a pasta /metadata e com o nome original do ficheiro, pois 
			é lá que são criados os ficheiros com o nome original*/
			strcpy(destMData, metadata);
			strcat(destMData, "/");
			strcat(destMData, comando[i+1]);
			/*
			printf("Diretoria data: %s\nDiretoria metadata: %s\n", destData, destMData );
			printf("Ficheiro : %s\n", comando[i+1]);
*/
			/* char** executar: vai ter as instruções usadas no exec, 
			para apagar os ficheiros passados como arg*/
			executar[0] = (char*) malloc(5*sizeof(char));
			strcpy(executar[0], "rm");
			/*sem a opção "-c" o execp nao realiza a funçao desejada */
			executar[1] = (char*) malloc(4*sizeof(char));
			strcpy(executar[1], "-rf");
			/*diretoria dos ficheiros a apagar*/
			executar[2] = (char*) malloc(strlen(destData)*sizeof(char));
			strcpy(executar[2], destData);
			executar[3] = (char*) malloc(strlen(destMData)*sizeof(char));
			strcpy(executar[3], destMData);
			executar[4] = NULL;
			/*fork para remover os ficheiros*/
			if(fork()==0){
				execvp("rm", executar);
				perror("rm");
				_exit(1);
				}else { wait(NULL); }
			}
		puts("--- Fim da remoçao do ficheiro ---");
		}

		for(i=0; ficheiros[i]!=NULL; i++)
			free(ficheiros[i]);
		for(i=0; executar[i]!=NULL; i++)
			free(executar[i]);

	return 0;

}
/*--------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------*/

int restore(char* comando[], char* data, char* metadata){
	/* declaração das variaveis */
	int  i = 0, n, fd;
	char res[MAX_SIZE2], destData[MAX_SIZE2], destMData[MAX_SIZE2], dirAtual[MAX_SIZE2];
	char *executar[MAX_SIZE2]; 
	char* sha1sumCode;

	puts("--- Restauro do ficheiro ---");

	/* Funçao que retorna a diretoria atual do utilizador 
	a condiçao if serve apenas para contornar warning de compilaçao face ao 
	valor de retorno de getcwd*/
	if((getcwd(dirAtual, sizeof(dirAtual)))!=NULL){}

	/* Colocar "/" no final da string que tem a diretoria atual, para que funcione nos exec */
	strcat(dirAtual, "/"); 
	/* Colocar a variavel passada como argumento, com o destino para a pasta /data, na variavel da funcao destData */
	strcpy(destData, data);
	/* Colocar "/" no final da string que tem a diretoria da pasta /data, para que funcione nos exec */
	strcat(destData, "/");
	/* Colocar a variavel passada como argumento, com o destino para a pasta /metadata, na variavel da funcao destData */
	strcpy(destMData, metadata);
	/* Colocar "/" no final da string que tem a diretoria da pasta /metada, para que funcione nos exec */
	strcat(destMData, "/");

	/* colocar o nome do ficheiro a restaurar, concatenado com a string que tem a diretoria para a pasta onde esta o seu bakcup */
	strcat(destMData, comando[i+1]);
	printf("dest metadata :   %s\n",destMData);
	/*Tentar abrir o ficheiro na pasta dos backups, para saber se ele existe 
	Se o ficheiro existir, é aberto em modo de leitura */
	fd = open(destMData, O_RDONLY);
	if(fd == -1){
		perror(destMData);
	}else { 
		/*Ler o conteudo do ficheiro --> sha1sum code do ficheiro */
		n = read(fd, res, sizeof(res));
		res[n] = '\0';

		sha1sumCode = (char*) malloc(strlen(res)*sizeof(char));
		strcpy(sha1sumCode, res);
		/*printf("Sha1sumCode: %s\n",sha1sumCode );*/
		/* O codigo sha1sum do ficheiro a restaurar está na pasta /data. 
		juntar à diretoria da pasta /data o codigo sha1sum do ficheiro para aceder ao ficheiro atravez da sua diretoria	*/
		strcat(destData, sha1sumCode);
		/* adicionar a extençao do ficheiro, que foi comprimido em zip*/
		strcat(destData, ".gz");

		/*printf("Diretoria data: %s\nDiretoria metadata: %s\n", destData, destMData );
		*/
		printf("Ficheiro a restaurar : %s\n", comando[i+1]);

		/* char** executar: vai ter as instruções usadas no exec, para copiar o ficheiro da /metadata, com o seu codigo sha1sum,
		para a diretoria atual do utilizador*/
		executar[0] = (char*) malloc(3*sizeof(char));
		strcpy(executar[0], "cp");
		executar[1] = (char*) malloc(strlen(destData)*sizeof(char));
		strcpy(executar[1], destData);
		executar[2] = (char*) malloc(strlen(dirAtual)*sizeof(char));
		strcpy(executar[2], dirAtual);
		executar[3] = NULL;
		/* fork para copiar o ficheiro do backup para a diretoria atual*/
		if(fork()==0) {
				execvp("cp", executar);
				perror("cp");
				_exit(1);
		}else {	wait(NULL);	}

		/*o ficheiro, movido para a diretoria atual, está no formato .gz
		Para usar o unzip, temos que ter numa variavel o nome do ficheiro: fileSha1sumCode.gz */
		/* char** executar: vai ter as instruções usadas no exec, para descomprimir o ficheiro que está na diretoria atual do utilizador*/
		executar[0] = (char*) malloc(7*sizeof(char));
		strcpy(executar[0], "gunzip");
		strcat(sha1sumCode, ".gz");
		executar[1] = (char*) malloc((strlen(sha1sumCode))*sizeof(char));
		strcpy(executar[1], sha1sumCode);
		/*printf("comand %s\n",executar[1] );*/
		executar[2] = NULL;
		/* fork para descomprimir o ficheiro movido para a diretoria atual*/
		if(fork()==0){
				execvp("gunzip", executar);
				perror("gunzip");
				_exit(1);
		}else {	wait(NULL);	}

		/* depois de descomprimir o ficheiro, será alterado o seu nome para o nome original, que foi passado como argumento à funçao  
		char** executar: vai ter as instruções usadas no exec, para alterar o nome do ficheiro que está na diretoria atual do utilizador*/
		executar[0] = (char*) malloc(3*sizeof(char));
		/* comando mv para alterar o nome */
		strcpy(executar[0], "mv");
		sha1sumCode = (char*) malloc(strlen(res)*sizeof(char));
		strcpy(sha1sumCode, res); /*o ficheiro descomprimido ainda tem o nome do sha1sum correspondente*/
		strcat(dirAtual, sha1sumCode); /*Para usar o mv, temos que ter numa variavel a diretoria até ao ficheiro */
		executar[1] = (char*) malloc(strlen(dirAtual)*sizeof(char));
		strcpy(executar[1], dirAtual);
		executar[2] = (char*) malloc(strlen(comando[i+1])*sizeof(char));
		/* nome origina do ficheiro restaurado */
		strcpy(executar[2], comando[i+1]);
		executar[3]=NULL;
		/* fork para alterar o nome o ficheiro para o seu nome original*/
		if(fork()==0){
			execvp("mv", executar);
			perror("mv");
			_exit(1);
		}else { wait(NULL); }

	puts("--- Fim do restauro do ficheiro ---");
	
	}
	/*for(i=0; executar[i]!=NULL; i++)
			free(executar[i]);
	*/

	return 0;

}


int backup(char** comando, char* data, char* metadata){
	/* declaração das variaveis */
	char *file, *sha1sumCode;
	int i, n, pd[2], fd1, fd2;
	char res[MAX_SIZE1], destData[MAX_SIZE2], destMData[MAX_SIZE2];
	char* ficheiros[MAX_SIZE2], *executar[MAX_SIZE2];
	
	/*Aplicar o comando sha1sum a todos os ficheiros que se deseja fazer backup;
	O nome dos ficheiros é recebido como argumento à funçao backup;
	*/
	pipe(pd);
	/* Por forma a reaver o resultado devolvido pelo sha1sum aplicado aos argumentos, é
	criado um pipe anónimo e redirecionada a entrada do pipe (pd[1]) para a saida do standart output
	perdefinida, usando a funcao dup2 */
	/* fork para obter o sha1sum, executado num execvp, dos ficheiros dados como argumento*/
	if(fork()==0) {
		close(pd[0]);
		dup2(pd[1], 1); close(pd[1]);
		comando[0] = (char*) malloc(8*sizeof(char));
		strcpy(comando[0], "sha1sum");
		execvp("sha1sum", comando); 
		perror("sha1sum");
		_exit(1);
	}
	else {
		wait(NULL);
		/*Ler o resultado devolvido pelo fork, atravez do refirecionamento da standrt output
		para a saida do pipe anonimo pd. --> Ler da saida do pipe = ler em pd[0]*/
		read(pd[0], res, sizeof(res));
		close(pd[0]); close(pd[1]);
		}

	/* O resutaldo do fork anterior será uma string com uma string do tipo:
		"sha1sum1 file1Name\n sha1sum2 file2Name\n (...) sha1sumN fileNName\n\0"
		Está string é então, inicialmente, partida pelos "\n" com ostrtok e colocada num array de string*/
	file = strtok(res, "\n"); 
	for(i=0; file!=NULL; i++){
		ficheiros[i]= (char*) malloc(strlen(file)*sizeof(char));
		strcpy(ficheiros[i], file);
		file = strtok(NULL, "\n");
	}
	ficheiros[i]=NULL;

	/* Em seguida, para cada string do tipo "sha1sumCode fileName", esta é partifa pelo
	caracter " " (espaço) para obter apenas o codigo sha1sum do ficheiro correspondente.
	O ficheiro do codigo obtido é o ficheiro na posiçao comando[i+1] (a primeira posicao do array
	de strings comando tem a string "backup"*/
	for(i=0; ficheiros[i]!=NULL; i++){
		puts("--- Backup do ficheiro ---");
		n = open(comando[i+1], O_RDONLY);
		if(n!=-1){
		/*obter o codigo sha1sum */
		sha1sumCode = strtok(ficheiros[i], " ");
		/*printf("Sha1sumCode%s\n",sha1sumCode );*/
		strcpy(destData, data); 
		strcat(destData, "/");
		/*concatenar à string com a diretoria para a pasta /data o codigo sha1sum do ficheiro 
		a fazer backup*/
		strcat(destData, sha1sumCode);
		/*adicionar a extençao ao ficheiro*/
		strcat(destData, ".gz");

		/*criar uma string com a diretoria para a pasta /metadata e com o nome original do ficheiro, pois 
		é lá que são criados os ficheiros com o nome original*/
		strcpy(destMData, metadata);
		strcat(destMData, "/");
		strcat(destMData, comando[i+1]);
		
		/*printf("Diretoria data: %s\nDiretoria metadata: %s\n", destData, destMData );
		*/printf("Ficheiro a restaurar: %s\n", comando[i+1]);

		/* char** executar: vai ter as instruções usadas no exec, 	
		para comprimir com o comando gzip, os ficheiros passados como arg*/
		executar[0] = (char*) malloc(5*sizeof(char));
		strcpy(executar[0], "gzip");
		/*sem a opção "-c" o execp nao realiza a funçao desejada */
		executar[1] = (char*) malloc(3*sizeof(char));
		strcpy(executar[1], "-c");
		/*nome do ficheiro a comprimir*/
		executar[2] = (char*) malloc(strlen(comando[i+1])*sizeof(char));
		strcpy(executar[2], comando[i+1]);
		executar[3] = NULL;
		/*fork para criar um ficheiro na pasta d backups /data, com nome igual ao codigo sha1sum do ficheiro 
		que se pertende fazer backup 
		Este ficheiro, irá conter nele a informaçao da compreçao com gzip do ficheiro a comprimir*/
		if(fork()==0){
			fd1 = open(destData, O_CREAT | O_RDWR | O_TRUNC, 0666);
			/*direcionar o standart output para o ficheiro criado. 
			O resultado do exec	aplicado ao ficheiro desejado, será guardado no ficheiro criado, com o nome do codigo
			sha1sum do ficheiro que se está a fazer backup*/
			dup2(fd1,1);
			close(fd1);
			execvp("gzip", executar);
			perror("gzip");
			_exit(1);
			}else { wait(NULL); }

		/*Criar um ficheiro na pasta /metadata, com o nome do ficheiro original. 
		Este ficheiro terá como contiudo o codigo sha1sum do ficheiro que se fez backup*/
		fd2 = open(destMData, O_CREAT | O_WRONLY | O_TRUNC, 0666);
		write(fd2, sha1sumCode, strlen(sha1sumCode));
		close(fd2);
			}
		puts("--- Fim do backup do ficheiro ---");

		}

		for(i=0; ficheiros[i]!=NULL; i++)
			free(ficheiros[i]);
		for(i=0; executar[i]!=NULL; i++)
			free(executar[i]);


	return 0;
}

int main(){
	/*declaração de variaveis */
	char *destino, *destData, *destMData, *destFifo, *destFifofile, *p;
	char buffer[MAX_SIZE1]; 
	char* comando[MAX_SIZE1];
	int i, n;


	char *user = (char*) getenv("USER"); /*obter o nome do utilizador da sessao atual*/

	/*colocar o nome do utilizador nas diretorias necessárias */
	asprintf(&destino, "/home/%s/.Backup", user);
	asprintf(&destData, "/home/%s/.Backup/data", user); 
	asprintf(&destMData, "/home/%s/.Backup/metadata", user);
	asprintf(&destFifo, "/home/%s/.Backup/Fifo", user); 

	mkdir(destino, 0777);	perror("Criar pasta ./Backup: "); /* Criar diretoria para o projeto */
	mkdir(destData, 0777); 	perror("Criar pasta /data: ");/* Criar pasta data na diretoria do projeto */
	mkdir(destMData, 0777); perror("Criar pasta /metadata: "); /* Criar pasta metadata na diretoria do projeto */
	mkdir(destFifo, 0777);	perror("Criar pasta /Fifo para o ficheiro da fifo");/* Criar pasta Fifo na diretoria do projeto */

	/*Criar o pipe com nome para receber, do cliente, o nome dos ficheiros onde se vai trabalhar*/
	asprintf(&destFifofile, "/home/%s/.Backup/Fifo/fifoBackup", user);
	mkfifo(destFifofile,0666); perror("Criação da Fifo com nome: ");
	
	int fifoFile;
	/*Abrir o pipe com nome para leitura */
	fifoFile = open(destFifofile, O_RDONLY);

	while(1){ 
	while((n=read(fifoFile, buffer, sizeof(buffer)))>0){ 
		perror("Leitura a partir da Fifo ");
		write(1, buffer, n);
		/*Partir a string recebida no pipe por palavras, separadas pos " "-espaço */
		p = strtok(buffer, " \r\n");
		for(i=0; p!=NULL; i++){
				comando[i] = (char*) malloc(sizeof(strlen(p)+1));
				strcpy(comando[i], p);
				p = strtok(NULL, " \r\n");
			}
			
		if(strcmp(comando[0], "restore")==0) {
			puts("SERVIDOR: restaurar. \n");
			restore(comando, destData, destMData);
		}
		if(strcmp(comando[0], "backup")==0) {
			puts("SERVIDOR: backup\n");
			backup(comando, destData, destMData);
		}
		if(strcmp(comando[0], "delete")==0){
			puts("SERVIDOR: apagar");
			delete(comando, destData, destMData);
		}
		if(strcmp(comando[0], "gc")==0){
			puts("SERVIDOR: limpar dados");
			limpar(destData, destMData);
		}

		puts("------------------------------------------------------");
	}
}


	close(fifoFile);
	return 0;
}