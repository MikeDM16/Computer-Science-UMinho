#define _GNU_SOURCE 
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>

	
int main(int argn, char* args[]){ 
	char *destFifofile, *comando;
	int i, rv = 0,tamanho = 0, fifoFile;
	/*a varivavel rv é exclusivamente usada para evitar warnings de compilação,
	face ao nao uso dos valores de retorno de determinadas funçoes usadas*/
	rv += rv; 
	 /*obter o nome do utilizador da sessao atual*/
	char *user = (char*) getenv("USER");
	/*colocar o nome do utilizador na diretoria necessária para abrir o pipe com nome */
	rv = asprintf(&destFifofile, "/home/%s/.Backup/Fifo/fifoBackup", user);
	/*abrir pipe com nome, apenas para escrita. Nele, seraõ passados os nomes dos ficheiros a trabalhar*/
	fifoFile = open(destFifofile, O_WRONLY);
	perror("Abertura Fifo com nome");
	
	/*Colocar as strings do array de strings args numa unica string separada por espaços. 
	Este processo é necessário para conseguir enviar o pedido dente utilizador para o servidor sem perder/misturar 
	pedidos de outros utilizadores*/
	for(i=1; i!=argn; i++){
		tamanho += strlen(args[i]) + 2; /* Adicionar espaço para cada string
		recebida como argumento + o caracter espaço */
	}

	/*adicionar cada uma das strings de *args[] ao char* comando. */
	comando = malloc(tamanho* sizeof(char));
	strcpy(comando, args[1]);
	for(i=2; i!=argn; i++){
		strcat(comando, " "); /*separadas pos " "-espaço */
		strcat(comando, args[i]);
	}
	strcat(comando,"\n");

	/*Escrever a string comando no pipe com nome, onde será lida no servidor e efectuado o pedido*/
	rv = write(fifoFile, comando, tamanho);

	/*Fechar pipe com nome apos utilizaçao*/
	close(fifoFile);

	return 0;
}