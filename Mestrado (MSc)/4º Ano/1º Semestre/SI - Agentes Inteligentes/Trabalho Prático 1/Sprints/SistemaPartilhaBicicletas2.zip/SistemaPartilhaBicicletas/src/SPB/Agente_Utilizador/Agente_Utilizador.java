package SPB.Agente_Utilizador;


import java.util.*;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.SimpleBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.df;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import SPB.*;
import SPB.Agente_Estacao.Estacao;

public class Agente_Utilizador extends Agent {
	private List<Estacao> estacoes; 
	private int nr_estacoes; 
	private Utilizador user; 
	
	public Agente_Utilizador() {
		this.estacoes = new ArrayList<Estacao>();	
	}
	
	public void setup(){
		System.out.println(this.getLocalName() + " iniciou.");
		
		// Registo do agente, no directory facilitator,  como sendo do tipo utilizador
		regista_Agente("Utilizador");
		
		// Comportamento para receber mensagens
		this.addBehaviour(new Recebe_Notificacoes(this));
				
		// Descobrir as esta��es, para escolher aleatoriamente uma origem e destino
		descobre_estacoes();
	}
	
	/* M�todo utilizado para comunicar com todos os agentes esta��o registados no DF
	 * de forma a descobrir as suas informacoes */
	private void descobre_estacoes() {
		//Procurar pelas esta��es iniciadas
		DFAgentDescription template = new DFAgentDescription();
		ServiceDescription sd 		= new ServiceDescription();
		sd.setType("Estacao");
		template.addServices(sd);
		
		DFAgentDescription[] disponiveis;
		try {
			disponiveis = DFService.search(this, template);
			for(int i = 0; i < disponiveis.length; i++) {
				ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);
				msg.addReceiver(disponiveis[i].getName());
				msg.setContent("informar ");
				send(msg);		
			}				
			int nr_estacoes = disponiveis.length;
			this.nr_estacoes = nr_estacoes; 
			
			this.estacoes = new ArrayList<Estacao>(nr_estacoes);
		}catch (FIPAException e) {	e.printStackTrace();	}
	}
	
	/*------------------------------------------------------------------------------------------------ 
	 * Classe Recebe_Notifica��es utilizada para fazer o tratamentos das mensagens recebidas
	 * por parte de um utilizador */
	private class Recebe_Notificacoes extends CyclicBehaviour{
		private Agente_Utilizador a_user; 
		private List<Estacao> estacoes; 
		private int recebidas = 0; 
		
		public Recebe_Notificacoes(Agente_Utilizador a) {
			this.a_user = a;
			this.estacoes = a.estacoes;
		}
		
		public void action() {
			ACLMessage msg = receive();
			if(msg!=null) {
				//System.out.println(this.a_user.getLocalName() + "Recebeu msg "+ msg.getContent());
				
				/* Com o m�todo descobre_estacoes, envia-se uma mensagem a cada um das estacoes 
				 * registadas no DF. Cada esta��o vai responder a essas mensagems com as suas 
				 * informa�oes, dando-se a conhecer ao utilizador. 
				 * Isto s� � feito 1x, quando se arranca com o utilizador */
				if(msg.getPerformative() == ACLMessage.INFORM) {
					String[] valores = msg.getContent().split(" ");					
					Estacao e = Estacao.str_to_Estacao(valores, msg.getSender()); 
					if (e != null) {
						if( this.recebidas < this.a_user.nr_estacoes ) {
							this.estacoes.add(recebidas, e);
							this.recebidas++;
						}
					}
					/* Depois de recebidas todas as respostas por parte dos agentes estacao, � possivel
					 * determinar uma localiza��o inicial e final atrav�s das esta��es que se deram a conhecer */
					if(this.recebidas == this.a_user.nr_estacoes) {
						this.a_user.estacoes = this.estacoes;
						this.a_user.addBehaviour(new Inicia_Utilizador(this.a_user));
					}
				}				
			}
		}
	} // fim da classe Recebe notifica��es 
	
	private class Update_Deslocacao extends TickerBehaviour{
		private Agente_Utilizador a_user;
		
		public Update_Deslocacao(Agente_Utilizador a, long timout) {
			super(a, timout);
			this.a_user = a; 
		}
		
		public void onTick() {
			Posicao atual = this.a_user.user.getAtual();
			Posicao origem = this.a_user.user.getInicio();
			Posicao destino = this.a_user.user.getFim();

			if( (atual.getX() != destino.getX()) || (atual.getY() != destino.getY())) {
				atual.deslocar(destino);
				this.a_user.user.setAtual(atual);
			}
			if( (atual.getX() == destino.getX()) || (atual.getY() == destino.getY())) {
				Estacao e = this.a_user.user.getDestino();
				// Notificar a esta��o final que o cliente chegou ao destino
				ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
				msg.addReceiver(e.getAgentID());
				msg.setContent("cliente end");
				send(msg);
				System.out.println(this.a_user.getLocalName() + " chegou ao destino");
				this.a_user.removeBehaviour(this);
				}
		}		
		
	}
	
	private class Notifica_Estacoes extends TickerBehaviour{
		private Agente_Utilizador a_user;
		private List<Estacao> comunicadas;
		
		public Notifica_Estacoes(Agente_Utilizador a, long timeout) {
			super(a, timeout);
			this.a_user = a;
			this.comunicadas = new ArrayList<Estacao>();
		}
		
		public void onTick() {
			List<Estacao> estacoes = this.a_user.estacoes;
			Posicao pos = this.a_user.user.getAtual();
			
			for(Estacao est : estacoes) {
				if((est.entrou_area_proximidade(pos)) && (!comunicadas.contains(est))) {
					ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
					msg.addReceiver(est.getAgentID());
					msg.setContent("cliente enter");
					send(msg);
					this.comunicadas.add(est);
				}
			}
		}
	}
	
	/*------------------------------------------------------------------------------------------------
	 * Classe inicia_utilizador representa o comportamento chamado quando j� se conhecem as esta��es 
	 * registadas no DF e se v�o escolher aleatoriamente duas para seres a origem e destino do 
	 * utilizador 	 */
	private class Inicia_Utilizador extends SimpleBehaviour{
		private boolean finished = false; 
		private List<Estacao> estacoes; 
		private Agente_Utilizador a_utilizador; 
		
		public Inicia_Utilizador(Agente_Utilizador a) {
			this.estacoes = a.estacoes; 
			this.a_utilizador = a; 
		}
		
		public void action() {
			Random rand = new Random();
			// Escolher um indice para selecionar uma estacao origem
			int o = rand.nextInt(estacoes.size());
			// Escolher indice para selecionar estacao destino =/= origem
			int d = o;
			while(d == o) {
				d = rand.nextInt(estacoes.size());
			}
			
			Estacao origem = this.estacoes.get(o);
			Estacao destino = this.estacoes.get(d);
			
			this.a_utilizador.user = new Utilizador(origem, origem, destino);
			// Notificar a esta��o inicial que o cliente fez uma reserva na mesma
			ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
			msg.addReceiver(origem.getAgentID());
			msg.setContent("cliente start");
			send(msg);		
			
			this.a_utilizador.addBehaviour(new Update_Deslocacao(this.a_utilizador, 500));
			this.a_utilizador.addBehaviour(new Notifica_Estacoes(this.a_utilizador, 2000));
			this.finished = true; 
		}
		
		public boolean done() { return this.finished;  }
	}// fim da classe Inicia_Utilizador
	
	/*------------------------------------------------------------------------------------------------*/
	
	/* Fun��o utilizada para registar no directory facilitator um agente, associando-o 
	 * a uma determinada fun�ao */
	private void regista_Agente(String tipo) {
		DFAgentDescription dfd = new DFAgentDescription();
		dfd.setName(getAID());
		ServiceDescription sd  = new ServiceDescription();
		sd.setType( tipo );
		sd.setName(this.getLocalName());
		dfd.addServices(sd);
		
		try { DFService.register(this, dfd);}
		catch (FIPAException e) {	e.printStackTrace();	}
	}
}
