package SPB.Agente_Estacao;

public class Negociacao {

}
