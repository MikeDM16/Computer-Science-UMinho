package SPB.Agente_Estacao;

import java.util.*;
import jade.core.AID;
import java.lang.Math;
import java.text.DecimalFormat;

import SPB.Posicao;

public class Estacao {
	private Posicao localizacao;
	private int area_proximidade, nr_bicicletas_atual, capacidade_maxima;
	private double ocupacao_ideal, lucro;
	private String nome;
	private AID agentID;
	private int nr_reservas = 0, nr_entregas = 0; 
	
	// Construtor da Classe
	public Estacao(String nome, AID agentID, Posicao pos, int raio, int bici_atual, int capacidade_max, int r, int e) {
		this.nome = nome;
		this.agentID = agentID;
		this.localizacao = pos;
		this.area_proximidade = raio;
		this.nr_bicicletas_atual = bici_atual;
		this.capacidade_maxima = capacidade_max; 
		this.nr_reservas = r;
		this.nr_entregas = e; 
	}

	
	/* M�todo utilizado para gerar os parametros de uma esta��o aleatoriamente
	 * dentro do contexto do sistema a desenvolver */
	public static Estacao gera_Estacao() {
		Random rand = new Random();
		
		// Determinar o raio de proximidade da esta��o
		int r_min = 15, r_max = 35;
		int raio = rand.nextInt( r_max + 1 - r_min) + r_min;
		
		// Determinar uma localiza��o para a esta��o 
		int x = rand.nextInt(100); 
		int y = rand.nextInt(100);
		Posicao pos = new Posicao(x, y); 
		
		/* Um esta��o ter� pelo menos 15 bicicletas para alugar
		 * Pode variar de 5 a 5, at� a um m�ximo de 35 */
		int n = rand.nextInt(5);
		int bici_atual = 15 + (n * 5);
	
		// A capacidade m�xima ser� de pelo menos 10% superior � capacidade inicial
		int c_min = 10, c_max = 30;
		n = rand.nextInt(c_max + 1 - c_min) + c_min;
		int capacidade_max = bici_atual + ((int) ((n * bici_atual) / 100) );
		
		int r = 0, e = 0; 
		return ( new Estacao("", null, pos, raio, bici_atual, capacidade_max, r, e) );
	}

	/* Metodo que determina se para cada elemento da lista de esta��es do 1� arg, alguma
	 * delas � vizinha da esta��o passada no 2� argumento*/
	public static boolean existe_vizinhanca(List<Estacao> estacoes, Estacao e) {
		boolean r = false;
		
		for (Estacao est : estacoes) {
			Posicao p1 = est.getLocalizacao();
			int r1 =  est.getArea_proximidade();
			Posicao p2 = e.getLocalizacao();
			int r2 = e.getArea_proximidade();
			
			/* Se a localiza��o de uma das esta��es estiver contida na primeira metade da �rea de
			 * proximidade da outra esta��o, ent�o as esta��es est�o demasiado proximas para coixistirem*/
			boolean cond1 = (Math.pow(p1.getX(),2) + Math.pow(p1.getY(), 2) <= Math.pow((r2/2), 2));
			boolean cond2 = (Math.pow(p2.getX(),2) + Math.pow(p2.getY(), 2) <= Math.pow((r1/2), 2));
			
			if (cond1 || cond2) {
				r = true;
				break;
			}
		}
		
		return r;
	}
	
	/* M�todo utilizado para retirar os valores existentes numa string.
	 * Ap�s parti-la, retira dela os valores dos atributos de uma esta��o */
	public static Estacao str_to_Estacao(String[] valores, AID agentID) {
		Estacao e = null;
		if (valores.length > 16) {
			String nome = valores[2];
			int x = Integer.parseInt(valores[4]);
			int y = Integer.parseInt(valores[6]);
			Posicao p = new Posicao(x, y);
			
			int raio = Integer.parseInt(valores[8]);
			int bici_atual = Integer.parseInt(valores[10]);
			int cap = Integer.parseInt(valores[12]);
			int r = Integer.parseInt(valores[14]);
			int et =  Integer.parseInt(valores[16]);
			e = new Estacao(nome, agentID, p, raio, bici_atual, cap, r, et);
		}
		return e; 
	}

	/* M�todo utilizado para passar os campos de uma esta��o para uma string, de forma a enviar
	 * estes dados no conteudo de uma mensagem ACL. */
	public String toMsg() {
		StringBuilder sb = new StringBuilder();
		
		sb.append("Nome " + this.nome + " ");
		sb.append("posX " + this.localizacao.getX() + " ");
		sb.append("posY " + this.localizacao.getY() + " ");
		sb.append("area " + this.area_proximidade + " ");
		sb.append("bici_atual " + this.nr_bicicletas_atual + " ");
		sb.append("capacidade " + this.capacidade_maxima + " ");
		sb.append("nr_Reservas " + this.nr_reservas + " ");
		sb.append("nr_entregas " + this.nr_entregas + " ");
		sb.append("ocupacao " + (this.nr_bicicletas_atual / this.capacidade_maxima));
		return sb.toString();
	}
	
	/*M�todos getters e setters necess�rios ao contexto*/
	public void inc_Nr_Reservas() { this.nr_reservas++; }
	public void inc_Nr_Entregas() { this.nr_entregas++; }
	public void inc_Nr_Bicicletas(int x) { this.nr_bicicletas_atual += x; }
	public void setNr_entregas(int e) {
		this.nr_entregas = e;
	}
	public void setLocalizacao(Posicao localizacao) {		
		this.localizacao = localizacao;	
	}
	public void setNr_reservas(int nr_reservas) {
		this.nr_reservas = nr_reservas;
	}
	public void setArea_proximidade(int area_proximidade) {	
		this.area_proximidade = area_proximidade;	
	}
	public void setNr_bicicletas_atual(int nr_bicicletas_atual) {
		this.nr_bicicletas_atual = nr_bicicletas_atual;
	}
	public void setCapacidade_maxima(int capacidade_maxima) {
		this.capacidade_maxima = capacidade_maxima;
	}
	public void setOcupacao_ideal(double ocupacao_ideal) {
		this.ocupacao_ideal = ocupacao_ideal;
	}
	public void setLucro(double lucro) {	this.lucro = lucro;		}
	public void setNome(String nome)   {	this.nome = nome;		}
	public void setAgentID(AID agentID){	this.agentID = agentID;	}
	
	public double getOcupacao_atual() { 
		double oc = ((double) (this.nr_bicicletas_atual)) / 
									((double) this.capacidade_maxima);
		double roundOff = Math.round(oc * 100.0) / 100.0;
		return (roundOff);
	}
	public int getNr_entregas() { 	return nr_entregas; }
	public int getNr_reservas() {		return nr_reservas;	}
	public Posicao getLocalizacao()  {	return localizacao;			}
	public int getArea_proximidade() {	return area_proximidade;	}
	public int getNr_bicicletas_atual() {	return nr_bicicletas_atual;	}
	public int getCapacidade_maxima() {	return capacidade_maxima;	}
	public double getOcupacao_ideal() {	return ocupacao_ideal;		}
	public double getLucro() {	return lucro;	}
	public String getNome()  {	return nome;	}
	public AID getAgentID()  {	return agentID;	}
	
	
	
}
