package SPB.Agente_Estacao;

import SPB.Posicao;
import SPB.Agente_Estacao.*;
import java.io.StringReader;
import java.util.*;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;

public class Agente_Estacao extends Agent{
	private Estacao e; 
	private Map<String, Estacao> vizinhanca; 
	
	public Agente_Estacao() {
		this.e = null;
		this.vizinhanca = new HashMap<String, Estacao>();
	}
	
	public void setup(){
		System.out.println(this.getLocalName() + " iniciou.");
		
		// Registo do agente, no directory facilitator,  como sendo do tipo estacao aluguer
		regista_Agente("Estacao");
		
		this.addBehaviour(new Recebe_Notificacoes(this));
		this.addBehaviour(new Informa_Estaoes(this, 3000));
	}
	
	
	/* ------------------------------------------------------------------------------------------------
	 * Classe respons�vel pelo envio de mensagens �s outras estacao, no processo de intra comunica��o
	 * entre esta��es  
	 * 
	 * -> Enivia msg para todas as esta��es. 
	 * -> Trabalho futuro: Enviar s� para uma dada vizinhan�a
	 * */
	private class Informa_Estaoes extends TickerBehaviour{
		private Agente_Estacao a_estacao; 
		
		public Informa_Estaoes(Agent a, long timeout) {
			super(a, timeout);
			this.a_estacao = (Agente_Estacao) a; 
		}
		
		public void onTick() {
			//Procurar pelos agentes esta��o registados
			DFAgentDescription template = new DFAgentDescription();
			ServiceDescription sd 		= new ServiceDescription();
			sd.setType("Estacao");
			template.addServices(sd);
			
			DFAgentDescription[] disponiveis;
			try {
				disponiveis = DFService.search(this.a_estacao, template);
				for(int i = 0; i < disponiveis.length; i++) {
					if(! disponiveis[i].getName().getLocalName().equals(this.a_estacao.getLocalName())) {
						ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
						msg.addReceiver(disponiveis[i].getName());
						msg.setContent("informar " + e.toMsg());
						send(msg);		
					}
				}	
			}catch (FIPAException e) {	e.printStackTrace();	}
		}
		
	}// Fim da classe Informa_Estaoes 
	
	/* ------------------------------------------------------------------------------------------------
	 * Classe respons�vel pelo tratamentos das mensagens recebidas por parte da estacao */
	private class Recebe_Notificacoes extends CyclicBehaviour {
		private Agente_Estacao a_estacao;
		
		public Recebe_Notificacoes(Agente_Estacao agente_Estacao) {
			this.a_estacao = agente_Estacao;
		}
		
		public void action() {
			ACLMessage msg = receive();
			if(msg != null) {
				//System.out.println(this.a_estacao.getLocalName() + ": " + msg.getContent());
				
				if(msg.getPerformative() == ACLMessage.INFORM) {
					String[] tokens = msg.getContent().split(" ");
					
					// Mensagem da interface com os valores iniciais dos parametros da esta��o
					if(tokens[0].equals("iniciar")) {
						iniciar_parametros_estacao(tokens);
					}
					/* Mensagens de outras esta��es pr�ximas que anunciam periodicamente os 
					 * seus dados de utiliza��o */
					if(tokens[0].equals("informar")) {
						atualiza_estacao(tokens, msg.getSender());
					}
					/* Mensagens recebidas pelos clientes que realizam aluguer nesta esta��o */
					if(tokens[0].equals("cliente")) {
						if(tokens[1].equals("start")) {
							this.a_estacao.e.inc_Nr_Reservas();
							this.a_estacao.e.inc_Nr_Bicicletas(-1);
						}
						if(tokens[1].equals("end")) {
							this.a_estacao.e.inc_Nr_Entregas();
							this.a_estacao.e.inc_Nr_Bicicletas(1);
						}
					}
					
				}
				
				// Requestes enviados pela interface para solicitar as informa��es da esta��o
				if(msg.getPerformative() == ACLMessage.REQUEST) {
					ACLMessage reply = msg.createReply();
					reply.setPerformative(ACLMessage.INFORM);
					reply.setContent("informar " + this.a_estacao.e.toMsg());
					send(reply);
				}
			}
		}
		
		/* M�todo utilizado quando se recebe uma mensagem INFORM vinda de outras esta��o, e se
		 * atualiza as informacoes sobre essa esta��o na lista de esta��es conhecidas 	 */
		private void atualiza_estacao(String[] valores, AID agentID) {
			Map<String, Estacao> vizinhanca = this.a_estacao.vizinhanca;
			Estacao e = Estacao.str_to_Estacao(valores, agentID);
			if (e != null) {	
				if(vizinhanca.containsKey(valores[2])) {
					Estacao aux = vizinhanca.get(valores[2]);
					aux = e; 
				}else {
					vizinhanca.put(valores[2], e);
				}
			}		
		}
		
		/* M�todo utilizado para iniciar os parametros de uma esta��o com os valores indicados
		 * no conteudo de uma mensagem mandada pela interface_SPB */
		private void iniciar_parametros_estacao(String[] valores) {
			if (valores.length > 12) {
				int x = Integer.parseInt(valores[4]);
				int y = Integer.parseInt(valores[6]);
				Posicao p = new Posicao(x, y);
				
				int raio = Integer.parseInt(valores[8]);
				int bici_atual = Integer.parseInt(valores[10]);
				int cap = Integer.parseInt(valores[12]);
				String n = this.a_estacao.getLocalName();
				AID aid = this.a_estacao.getAID();
				int r = 0, et =0;
				this.a_estacao.e = new Estacao(n, aid, p, raio, bici_atual, cap, r, et);
			}		
		}
		
	} /* Fim da class RecebeNotifica��es - CyclicBehaviour para receber mensagens
	 ------------------------------------------------------------------------------------------------ */
	
	
	/* Fun��o utilizada para registar no directory facilitator um agente, associando-o 
	 * a uma determinada fun�ao */
	private void regista_Agente(String tipo) {
		DFAgentDescription dfd = new DFAgentDescription();
		dfd.setName(getAID());
		ServiceDescription sd  = new ServiceDescription();
		sd.setType( tipo );
		sd.setName(this.getLocalName());
		dfd.addServices(sd);
		
		try { DFService.register(this, dfd);}
		catch (FIPAException e) {	e.printStackTrace();	}
	}
}
