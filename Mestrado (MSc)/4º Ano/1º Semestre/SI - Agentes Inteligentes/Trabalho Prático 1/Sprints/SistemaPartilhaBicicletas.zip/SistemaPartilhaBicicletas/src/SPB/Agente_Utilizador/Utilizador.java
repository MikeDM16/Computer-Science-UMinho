package SPB.Agente_Utilizador;

import SPB.Agente_Estacao.Estacao;
import SPB.Posicao;

public class Utilizador {
	private Estacao origem, destino;
	private Posicao inicio, atual, fim; 
	
	public Utilizador(Estacao origem, Estacao atual, Estacao destino) {
		this.origem = origem;
		this.destino = destino;
		
		this.inicio = new Posicao( origem.getLocalizacao().getX(), origem.getLocalizacao().getY());
		this.atual  = new Posicao( origem.getLocalizacao().getX(), origem.getLocalizacao().getY());;
		this.fim	= new Posicao( destino.getLocalizacao().getX(), destino.getLocalizacao().getY());
		
	}

	/* M�todos getters e setters neces�rios ao contexto */
	public Estacao getOrigem() {	return origem;	}
	public Estacao getDestino() {	return destino;	}
	public Posicao getInicio() {	return inicio;	}
	public Posicao getAtual() {	return atual;		}
	public Posicao getFim() {	return fim;	}
	
	public void setOrigem(Estacao origem) {		this.origem = origem;	}
	public void setDestino(Estacao destino) {		this.destino = destino;	}
	public void setInicio(Posicao inicio) {		this.inicio = inicio;	}
	public void setAtual(Posicao atual) {		this.atual = atual;	}
	public void setFim(Posicao fim) {		this.fim = fim;	}

	
}
