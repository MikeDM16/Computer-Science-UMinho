package SPB;

import SPB.Agente_Estacao.Estacao;
import SPB.Agente_Utilizador.Utilizador;
import java.util.ArrayList;
import java.util.List;
import jade.lang.acl.ACLMessage;

public class Negociacao {
	private Utilizador u;
	private Estacao est;
	private List<String> historico = new ArrayList<String>(); 
	private boolean terminada = false; 
	
	public Negociacao(Utilizador u, Estacao est, List<String> l) {
		this.u = u;
		this.est = est;
		this.historico = l;
	}
	
	public void add_Msg(String msg) {
		this.historico.add(msg);
	}
	
	public void set_Terminada(boolean b) {
		this.terminada = b;
	}
}
