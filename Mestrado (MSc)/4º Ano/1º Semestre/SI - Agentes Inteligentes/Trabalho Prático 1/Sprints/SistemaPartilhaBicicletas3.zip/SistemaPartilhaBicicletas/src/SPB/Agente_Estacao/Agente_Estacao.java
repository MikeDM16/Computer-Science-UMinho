package SPB.Agente_Estacao;

import SPB.Negociacao;
import SPB.Posicao;
import SPB.Agente_Estacao.*;
import SPB.Agente_Utilizador.Utilizador;

import java.io.StringReader;
import java.util.*;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.ParallelBehaviour;
import jade.core.behaviours.SimpleBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;

public class Agente_Estacao extends Agent{
	private Estacao e; 
	private Map<String, Estacao> vizinhanca; 
	
	public Agente_Estacao() {
		this.e = null;
		this.vizinhanca = new HashMap<String, Estacao>();
	}
	
	public void setup(){
		System.out.println(this.getLocalName() + " iniciou.");
		
		// Registo do agente, no directory facilitator,  como sendo do tipo estacao aluguer
		regista_Agente("Estacao");
		
		this.addBehaviour(new Recebe_Notificacoes(this));
		this.addBehaviour(new Informa_Estaoes(this, 5000));
	}
	
	
	/* ------------------------------------------------------------------------------------------------
	 * Classe respons�vel pelo envio de mensagens �s outras estacao, no processo de intra comunica��o
	 * entre esta��es  
	 * 
	 * -> Enivia msg para todas as esta��es. 
	 * -> Trabalho futuro: Enviar s� para uma dada vizinhan�a
	 * */
	private class Informa_Estaoes extends TickerBehaviour{
		private Agente_Estacao a_estacao; 
		
		public Informa_Estaoes(Agent a, long timeout) {
			super(a, timeout);
			this.a_estacao = (Agente_Estacao) a; 
		}
		
		public void onTick() {
			//Procurar pelos agentes esta��o registados
			DFAgentDescription template = new DFAgentDescription();
			ServiceDescription sd 		= new ServiceDescription();
			sd.setType("Estacao");
			template.addServices(sd);
			
			DFAgentDescription[] disponiveis;
			try {
				disponiveis = DFService.search(this.a_estacao, template);
				// Comportamento paralelo para comunicar em parelelo com as diferentes esta��es
				ParallelBehaviour pb = new ParallelBehaviour(this.a_estacao, ParallelBehaviour.WHEN_ALL) {
					public int onEnd() {
						return 0;
					}
				};	
				this.a_estacao.addBehaviour(pb);
				
				for(int i = 0; i < disponiveis.length; i++) {
					pb.addSubBehaviour(new Envia_mensagem(this.a_estacao, disponiveis[i].getName()));
				}	
			}catch (FIPAException e) {	e.printStackTrace();	}
		}
		
		private class Envia_mensagem extends SimpleBehaviour{
			private Agente_Estacao a_estacao;
			private boolean finished = false; 
			private AID destino;
			
			public Envia_mensagem(Agente_Estacao a, AID destino) {
				this.a_estacao = a; 
				this.destino = destino;
			}
			
			public void action() {
				// condi��o para evitar que a esta��o envie msg de informacao para si mesma
				if(!this.destino.getLocalName().equals(this.a_estacao.getLocalName())) {
					ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
					msg.addReceiver(this.destino);
					msg.setContent("informar " + this.a_estacao.e.toMsg());
					send(msg);		
					this.finished = true;
				}
			}
			
			public boolean done() {return this.finished; }
		}
		
	}// Fim da classe Informa_Estaoes 
	
	/* ------------------------------------------------------------------------------------------------
	 * Classe respons�vel pelo tratamentos das mensagens recebidas por parte da estacao */
	private class Recebe_Notificacoes extends CyclicBehaviour {
		private Agente_Estacao a_estacao;
		private Map<AID, Negociacao> negociacoes; 
		
		public Recebe_Notificacoes(Agente_Estacao agente_Estacao) {
			this.a_estacao = agente_Estacao;
			this.negociacoes = new HashMap<AID, Negociacao>();
		}
		
		public void action() {
			ACLMessage msg = receive();
			if(msg != null) {
				//System.out.println(this.a_estacao.getLocalName() + ": " + msg.getContent());
				int perf = msg.getPerformative();
				if(perf == ACLMessage.INFORM) {
					String[] tokens = msg.getContent().split(" ");
					
					// Mensagem da interface com os valores iniciais dos parametros da esta��o
					if(tokens[0].equals("iniciar")) {	iniciar_parametros_estacao(tokens);	}
					
					/* Mensagens de outras esta��es pr�ximas que anunciam periodicamente 
					 * os seus dados de utiliza��o */
					if(tokens[0].equals("informar")) {	atualiza_estacao(tokens, msg.getSender());	}
					
					/* Mensagens recebidas pelos clientes que realizam aluguer nesta esta��o */
					if(tokens[0].equals("cliente")) {
						/* Msg dos clientes que iniciam na esta��o e nela alugam uma bicicleta */
						if(tokens[1].equals("start")) {
							this.a_estacao.e.inc_Nr_Reservas();
							this.a_estacao.e.inc_Nr_Bicicletas(-1);
						}
						/* Msg dos clientes que terminam na esta��o e entregam nela a bicicleta alugada */
						if(tokens[1].equals("end")) {
							this.a_estacao.e.inc_Nr_Entregas();
							this.a_estacao.e.inc_Nr_Bicicletas(1);
						}
						/* Msg dos clientes quando entram na �rea de proximidade da estacao */
						if(tokens[1].equals("enter")) {
							regista_negociacao( msg.getSender(), msg);
						}
					}					
				}
				
				if( (perf == ACLMessage.AGREE) ||	(perf == ACLMessage.REJECT_PROPOSAL)) {
					regista_negociacao( msg.getSender(), msg);
				}
				
				// Requestes enviados pela interface para solicitar as informa��es da esta��o
				if(perf == ACLMessage.REQUEST) {
					ACLMessage reply = msg.createReply();
					reply.setPerformative(ACLMessage.INFORM);
					reply.setContent("informar " + this.a_estacao.e.toMsg());
					send(reply);
				}
			}
		}
		
		private void regista_negociacao( AID user, ACLMessage msg) {
			//System.out.println(this.a_estacao.getLocalName() + " possivel negociacao");
			Estacao est = this.a_estacao.e;
			Posicao p_est = est.getLocalizacao();
			
			// Se ainda nao foi feita nenhuma comunica��o com o agente utilizador
			if ((!this.negociacoes.containsKey(user)) && (msg.getPerformative()==ACLMessage.INFORM)) {
				inicia_negociacao(user, msg);
			}
			if((this.negociacoes.containsKey(user)) && (msg.getPerformative()==ACLMessage.AGREE)) {
				this.a_estacao.e.inc_Propostas_Aceites();
				/* Adicionar a ultima mensagem recebida ao historico de msgs da negocia��o, e marcar a negociacao 
				 * como terminada */
				this.negociacoes.get(user).add_Msg(msg.getContent());
				System.out.println(this.a_estacao.getLocalName() + ": " + user.getLocalName() + " aceitou proposta");
				this.negociacoes.get(user).set_Terminada(true);
			}
			if((this.negociacoes.containsKey(user)) && (msg.getPerformative()==ACLMessage.REJECT_PROPOSAL)) {
				this.a_estacao.e.inc_Propostas_Rejeitadas();
				/* Adicionar a ultima mensagem recebida ao historico de msgs da negocia��o, e marcar a negociacao 
				 * como terminada */
				this.negociacoes.get(user).add_Msg(msg.getContent());

				System.out.println(this.a_estacao.getLocalName() + ": " + user.getLocalName() + " rejeitou proposta");
				this.negociacoes.get(user).set_Terminada(true);
			}
		}
		
		private void inicia_negociacao( AID user, ACLMessage msg) {
			Estacao est = this.a_estacao.e;
			Posicao p_est = est.getLocalizacao();
			ACLMessage prop = new ACLMessage(ACLMessage.PROPOSE);
			prop.addReceiver(user);
			
			Utilizador u = Utilizador.str_to_Utilizador(msg.getContent());
			Posicao p_user = u.getFim();
			
			if(est.is_Sobrelotada()) { // Caso a esta��o esteja sobrelotada
				/* Caso a esta��o destino do utilizador que entroi na �rea de proximidade seja 
				 * esta esta��o atualmente sobrelotada, vamos reencaminh�-lo para outra estacao */
				if( (p_user.getX() == p_est.getX()) && (p_user.getY() == p_est.getY())) {
					int desconto = 30;
					Estacao new_destino = escolhe_Estacao(u.getAtual());
					if(new_destino == null) { return; }
					Posicao p = new_destino.getLocalizacao();						
					// conteudo msg: "propost px py desconto desc"
					prop.setContent("propose " + p.getX() + " " + p.getY() + ", desconto " + desconto + "");
					System.out.println(this.a_estacao.getLocalName() + " vai tentar deslocar o " + user.getLocalName());
					
				}					
			}
			
			// Caso a esta��o esteja com falta de equipamento
			if(this.a_estacao.e.is_Underlotada()) {
				int desconto = 20;
				// conteudo msg: "propose px py desconto desc"
				prop.setContent("propose " + p_est.getX() + " " + p_est.getY() + ", desconto " + desconto + "");					
				System.out.println(this.a_estacao.getLocalName() + " vai tentar cativar o " + user.getLocalName());
			}
			
			send(prop);	
			
			// lista l representa o hist�rico inicial de msg trocadas entre os agentes
			List<String> l = new ArrayList<String>();
			l.add(msg.getContent());
			l.add(prop.getContent());
			Negociacao n = new Negociacao(u, est, l);
			this.negociacoes.put(user, n);
		}
		
		/* m�todo utilizado para determinar, das esta��es conhecidas, qual a que � 
		 * mais proxima da sua posi��o atual*/
		public Estacao escolhe_Estacao(Posicao p_user) {
			Estacao escolhida = null;
			double d_escolhido = 10000;
		
			Map<String, Estacao> estacoes = this.a_estacao.vizinhanca;
			for(Map.Entry<String, Estacao> entry : estacoes.entrySet()) {
				Estacao est = entry.getValue();

				if(est.distancia(p_user) < d_escolhido) {
					escolhida = est;
					d_escolhido = est.distancia(p_user);
				}
			}
		
			return escolhida;
		}
		
		/* M�todo utilizado quando se recebe uma mensagem INFORM vinda de outras esta��o, e se
		 * atualiza as informacoes sobre essa esta��o na lista de esta��es conhecidas 	 */
		private void atualiza_estacao(String[] valores, AID agentID) {
			Map<String, Estacao> vizinhanca = this.a_estacao.vizinhanca;
			Estacao e = Estacao.str_to_Estacao(valores, agentID);
			if (e != null) {	
				if(vizinhanca.containsKey(valores[2])) {
					Estacao aux = vizinhanca.get(valores[2]);
					aux = e; 
				}else {
					vizinhanca.put(valores[2], e);
				}
			}		
		}
		
		/* M�todo utilizado para iniciar os parametros de uma esta��o com os valores indicados
		 * no conteudo de uma mensagem mandada pela interface_SPB */
		private void iniciar_parametros_estacao(String[] valores) {
			if (valores.length > 12) {
				int x = Integer.parseInt(valores[4]);
				int y = Integer.parseInt(valores[6]);
				Posicao p = new Posicao(x, y);
				
				int raio = Integer.parseInt(valores[8]);
				int bici_atual = Integer.parseInt(valores[10]);
				int cap = Integer.parseInt(valores[12]);
				String n = this.a_estacao.getLocalName();
				AID aid = this.a_estacao.getAID();
				this.a_estacao.e = new Estacao(n, aid, p, raio, bici_atual, cap, 0,0,0,0);
			}		
		}
		
	} /* Fim da class RecebeNotifica��es - CyclicBehaviour para receber mensagens
	 ------------------------------------------------------------------------------------------------ */
	
	
	/* Fun��o utilizada para registar no directory facilitator um agente, associando-o 
	 * a uma determinada fun�ao */
	private void regista_Agente(String tipo) {
		DFAgentDescription dfd = new DFAgentDescription();
		dfd.setName(getAID());
		ServiceDescription sd  = new ServiceDescription();
		sd.setType( tipo );
		sd.setName(this.getLocalName());
		dfd.addServices(sd);
		
		try { DFService.register(this, dfd);}
		catch (FIPAException e) {	e.printStackTrace();	}
	}
}
