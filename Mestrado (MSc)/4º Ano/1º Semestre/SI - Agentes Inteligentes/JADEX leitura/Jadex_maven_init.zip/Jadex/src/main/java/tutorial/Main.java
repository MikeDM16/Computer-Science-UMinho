package tutorial;

import jadex.base.PlatformConfiguration;
import jadex.base.Starter;
import jadex.bridge.IExternalAccess;
import jadex.bridge.service.search.SServiceProvider;
import jadex.bridge.service.types.cms.IComponentManagementService;
import jadex.commons.future.IFuture;

public class Main
{
	public static void main(String[] args)
	{
		PlatformConfiguration configuration = PlatformConfiguration.getDefault();
		configuration.setPlatformName("jadexplatform");
		configuration.setGui(true);
		configuration.setCli(true);
		configuration.setLogging(false);
		configuration.setTcpPort(9788);
		
		IExternalAccess platform = Starter.createPlatform(configuration).get();
		IFuture<IComponentManagementService> fut = SServiceProvider.getService(platform, IComponentManagementService.class);
		IComponentManagementService cms = fut.get();
		
		//createComponent(AID, ClassPath, Arguments)
		cms.createComponent("HelloAgent", "tutorial.HelloAgent.class", null);
		
	}
}
